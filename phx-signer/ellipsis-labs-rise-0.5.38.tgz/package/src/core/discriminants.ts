import { sha256 } from "@noble/hashes/sha2.js";

export const sha2_const = (input: string): Uint8Array => {
  const inputBytes = new TextEncoder().encode(input);
  const hash = sha256(inputBytes);
  return hash.subarray(0, 8);
};

type DiscriminantMap = Record<string, Uint8Array>;

export const DISCRIMINANTS: DiscriminantMap = {
  PLACE_MARKET_ORDER: sha2_const("global:place_market_order"),
  PLACE_MARKET_ORDER_DELEGATED: sha2_const(
    "global:place_market_order_delegated"
  ),
  PLACE_LIMIT_ORDER: sha2_const("global:place_limit_order"),
  PLACE_MULTI_LIMIT_ORDER: sha2_const("global:place_multi_limit_order"),
  PLACE_MULTI_LIMIT_ORDER_V2: sha2_const("global:place_multi_limit_order_v2"),
  CANCEL_ORDERS_BY_ID: sha2_const("global:cancel_orders_by_id"),
  CANCEL_ALL: sha2_const("global:cancel_all"),
  CANCEL_UP_TO: sha2_const("global:cancel_up_to"),
  UNCROSS_CRANK: sha2_const("global:uncross_crank"),
  DEPOSIT_FUNDS: sha2_const("global:deposit_funds"),
  WITHDRAW_FUNDS: sha2_const("global:withdraw_funds"),
  REGISTER_TRADER: sha2_const("global:register_trader"),
  REALLOC_TRADER: sha2_const("global:realloc_trader"),
  DELEGATE_TRADER: sha2_const("global:delegate_trader"),
  SET_TRADER_CAPABILITIES_DELEGATED: sha2_const(
    "global:set_trader_capabilities_delegated"
  ),
  TRANSFER_COLLATERAL: sha2_const("global:transfer_collateral"),
  AUTHORIZED_TRANSFER_COLLATERAL: sha2_const(
    "global:authorized_transfer_collateral"
  ),
  TRANSFER_COLLATERAL_CHILD_TO_PARENT: sha2_const(
    "global:transfer_collateral_child_to_parent"
  ),
  SYNC_PARENT_TO_CHILD: sha2_const("global:sync_parent_to_child"),
  SYNC_NATIVE: sha2_const("global:sync_native"),
  WITHDRAW_NATIVE_SOL: sha2_const("global:withdraw_native_sol"),
  TRANSFER_NATIVE_SOL: sha2_const("global:transfer_native_sol"),
  TRANSFER_NATIVE_SOL_FROM_CHILD_TO_PARENT: sha2_const(
    "global:transfer_native_sol_from_child_to_parent"
  ),
  LIQUIDATE_NATIVE_SOL: sha2_const("global:liquidate_native_sol"),
  SWAP_NATIVE: sha2_const("global:swap_native"),
  REGISTER_SPLINE: sha2_const("global:register_spline"),
  DEACTIVATE_SPLINE: sha2_const("global:deactivate_spline"),
  UPDATE_SPLINE_PRICE: sha2_const("global:update_spline_price"),
  UPDATE_SPLINE_PARAMETERS: sha2_const("global:update_spline_parameters"),
  UPDATE_SPLINE_POSITION_LIMITS_CONFIG: sha2_const(
    "global:update_spline_position_limits_config"
  ),
  PLACE_STOP_LOSS: sha2_const("global:place_stop_loss"),
  CANCEL_STOP_LOSS: sha2_const("global:cancel_stop_loss"),
  CREATE_PERMISSION: sha2_const("global:create_permission"),
  SET_PERMISSION: sha2_const("global:set_permission"),
  SET_PERMISSION_DELEGATED: sha2_const("global:set_permission_delegated"),
  CREATE_ESCROW_ACCOUNT: sha2_const("global:create_escrow_account"),
  CREATE_ESCROW_REQUEST: sha2_const("global:create_escrow_request"),
  ACCEPT_ESCROW_REQUEST: sha2_const("global:accept_escrow_request"),
  CANCEL_ESCROW_REQUEST: sha2_const("global:cancel_escrow_request"),
  CREATE_CONDITIONAL_ORDERS_ACCOUNT: sha2_const(
    "global:create_conditional_orders_account"
  ),
  PLACE_POSITION_CONDITIONAL_ORDER: sha2_const(
    "global:place_position_conditional_order"
  ),
  CANCEL_CONDITIONAL_ORDER: sha2_const("global:cancel_conditional_order"),
  PLACE_ATTACHED_CONDITIONAL_ORDER: sha2_const(
    "global:place_attached_conditional_order"
  ),
  PLACE_LIMIT_ORDER_WITH_CONDITIONALS: sha2_const(
    "global:place_limit_order_with_conditionals"
  ),
  UPDATE_TRADER_STATE: sha2_const("global:update_trader_state"),
};

export const EMBER_DISCRIMINANTS: DiscriminantMap = {
  DEPOSIT: sha2_const("global:deposit"),
  WITHDRAW: sha2_const("global:withdraw"),
};

export const FLICKER_DISCRIMINANTS: DiscriminantMap = {
  INIT: sha2_const("global:init"),
  NAME_SUCCESSOR: sha2_const("global:name_successor"),
  CLAIM_SUCCESSOR: sha2_const("global:claim_successor"),
  CREATE_TWAP_ACCOUNT: sha2_const("global:create_twap_account"),
  PLACE_TWAP_ORDER: sha2_const("global:place_twap_order"),
  EXECUTE_TWAP_ORDER: sha2_const("global:execute_twap_order"),
  CANCEL_TWAP_ORDER: sha2_const("global:cancel_twap_order"),
  CLOSE_INACTIVE_TWAP_ACCOUNT: sha2_const("global:close_inactive_twap_account"),
  LOG: sha2_const("global:log"),
  LOG_EVENT_LENGTHS: sha2_const("global:log_event_lengths"),
};

export const ACCOUNT_DISCRIMINANTS: DiscriminantMap = {
  CONDITIONAL_ORDER_COLLECTION: sha2_const("account:conditional_order"),
  GLOBAL_CONFIGURATION: sha2_const("account:global_configuration"),
  MARKET: sha2_const("account:market"),
  ORDERBOOK: sha2_const("account:orderbook"),
  ORDERBOOK_HEADER: sha2_const("account:orderbook"),
  ACTIVE_TRADER_BUFFER_HEADER: sha2_const("account:active_trader_buffer"),
  ACTIVE_TRADER_BUFFER_ARENA_HEADER: sha2_const(
    "account:active_trader_buffer_arena"
  ),
  GLOBAL_TRADER_INDEX_HEADER: sha2_const("account:global_trader_index"),
  GLOBAL_TRADER_INDEX_ARENA_HEADER: sha2_const(
    "account:global_trader_index_arena"
  ),
  SPLINE_COLLECTION: sha2_const("account:spline_collection"),
  TRADER: sha2_const("account:trader"),
  DYNAMIC_TRADER: sha2_const("account:dynamic_trader"),
  PERP_ASSET_MAP: sha2_const("account:perp_asset_map"),
  PERMISSION_ACCOUNT: sha2_const("account:permission_account"),
  STOP_LOSSES: sha2_const("account:stop_losses"),
  WITHDRAW_QUEUE_HEADER: sha2_const("account:withdraw_queue"),
};
