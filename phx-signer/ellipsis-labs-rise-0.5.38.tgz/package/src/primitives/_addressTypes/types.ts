import type { Address } from "@solana/kit";
import type { Branded } from "@/core/utils/branded";

export type PhoenixProgramAddress = Branded<Address, "PhoenixProgram">;
export type LogAuthorityAddress = Branded<Address, "LogAuthority">;
export type GlobalConfigurationAddress = Branded<Address, "GlobalConfig">;
export type MintAddress = Branded<Address, "Mint">;
export type SPLTokenProgramAddress = Branded<Address, "SPLTokenProgram">;
export type SPLATAProgramAddress = Branded<Address, "SPLATAProgram">;
export type SystemProgramAddress = Branded<Address, "SystemProgram">;
export type EmberProgramAddress = Branded<Address, "EmberProgram">;
export type FlameProgramAddress = Branded<Address, "FlameProgram">;
export type FlickerProgramAddress = Branded<Address, "FlickerProgram">;

export type Authority = Branded<Address, "Authority">;
export type PerpAssetMapAddress = Branded<Address, "PerpAssetMap">;
export type TraderAddress = Branded<Address, "Trader">;
export type MarketAddress = Branded<Address, "Market">;
export type SplineCollectionAddress = Branded<Address, "SplineCollection">;
export type TwapGlobalStateAddress = Branded<Address, "TwapGlobalState">;
export type TwapAccountAddress = Branded<Address, "TwapAccount">;
export type TwapLogAuthorityAddress = Branded<Address, "TwapLogAuthority">;

export type ActiveTraderBufferHeaderAddress = Branded<
  Address,
  "ActiveTraderBufferHeader"
>;
export type ActiveTraderBufferArenaAddress = Branded<
  Address,
  "ActiveTraderBufferArena"
>;

export type ActiveTraderBufferAddressArray = [
  ActiveTraderBufferHeaderAddress,
  ...ActiveTraderBufferArenaAddress[],
];

export type GlobalTraderIndexHeaderAddress = Branded<
  Address,
  "GlobalTraderIndexHeader"
>;
export type GlobalTraderIndexArenaAddress = Branded<
  Address,
  "GlobalTraderIndexArena"
>;

export type GlobalTraderIndexAddressArray = [
  GlobalTraderIndexHeaderAddress,
  ...GlobalTraderIndexArenaAddress[],
];

export type TokenAccountAddress = Branded<Address, "TokenAccount">;
export type GlobalVaultAddress = Branded<Address, "GlobalVault">;
/** PDA that custodies native SOL spot collateral and signs the program's own
 * withdrawals of it. Seeds: `["native_sol"]`. */
export type NativeSolAuthorityAddress = Branded<Address, "NativeSolAuthority">;
export type WithdrawQueueAddress = Branded<Address, "WithdrawQueue">;
export type EmberStateAddress = Branded<Address, "EmberState">;
export type EmberVaultAddress = Branded<Address, "EmberVault">;
