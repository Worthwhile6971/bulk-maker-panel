import { MAX_SUBACCOUNTS } from "@/core/helpers";
import {
  buildCreateConditionalOrdersAccountIx,
  type CreateConditionalOrdersAccountIx,
} from "@/core/ixBuilders/CreateConditionalOrdersAccount";
import {
  buildHawkeyeViewBboIx,
  buildHawkeyeViewFundingIx,
  buildHawkeyeViewLiquidationPriceIx,
  buildHawkeyeViewMarginForAssetIx,
  buildHawkeyeViewMarginIx,
} from "@/hawkeye";
import {
  buildPlaceAttachedConditionalOrderIx,
  type PlaceAttachedConditionalOrderIx,
} from "@/core/ixBuilders/PlaceAttachedConditionalOrder";
import {
  buildPlaceLimitOrderWithConditionalsIx,
  type PlaceLimitOrderWithConditionalsIx,
} from "@/core/ixBuilders/PlaceLimitOrderWithConditionals";
import {
  buildPlacePositionConditionalOrderIx,
  type PlacePositionConditionalOrderIx,
} from "@/core/ixBuilders/PlacePositionConditionalOrder";
import type { PhoenixOrderPacketBuilders } from "@/orderPackets";
import { getPhoenixConditionalOrdersAddress } from "@/pdas";
import { MarginType, ticks, toMaxPositions } from "@/primitives";
import type {
  ActiveTraderBufferAddressArray,
  Authority,
  EmberStateAddress,
  EmberVaultAddress,
  GlobalConfigurationAddress,
  GlobalVaultAddress,
  GlobalTraderIndexAddressArray,
  LogAuthorityAddress,
  MarketAddress,
  MintAddress,
  PerpAssetMapAddress,
  PhoenixProgramAddress,
  SplineCollectionAddress,
  Symbol,
  TokenAccountAddress,
  TraderAddress,
  WithdrawQueueAddress,
} from "@/primitives";
import type { InstructionsWithAccountsAndData } from "@/primitives/_utilityTypes";
import type { Address } from "@solana/kit";
import {
  buildTriggerOrderParams,
  normalizeTriggerOrderParams,
} from "../conditionalOrders";
import {
  buildDepositIxsResolved,
  buildDepositFundsIxResolved,
  buildEmberDepositIxResolved,
  buildEmberWithdrawIxResolved,
  buildTransferCollateralChildToParentIxResolved,
  buildTransferCollateralIxResolved,
  buildWithdrawFundsIxResolved,
  buildWithdrawIxsResolved,
} from "./collateral";
import { buildCreateEscrowRequestIxResolved } from "./escrow";
import {
  buildCancelAllIxResolved,
  buildCancelOrdersByIdIxResolved,
  buildCancelUpToIxResolved,
  buildUncrossCrankIxResolved,
  buildPlaceLimitOrderIxResolved,
  buildPlaceMarketOrderDelegatedIxResolved,
  buildPlaceMarketOrderIxResolved,
  buildPlacePostOnlyOrderIxResolved,
  buildPlaceStopLossIxResolved,
} from "./orders";
import {
  buildCancelStopLossIxResolved,
  buildDelegateTraderIxResolved,
  buildOnboardTraderDelegatedIxResolved,
  buildRegisterTraderIxResolved,
  buildSyncParentToChildIxResolved,
} from "./trader";
import type {
  BuildRegisterTraderParams,
  ClientCancelAllInput,
  ClientCancelOrdersByIdInput,
  ClientCancelStopLossInput,
  ClientCancelUpToInput,
  ClientUncrossCrankInput,
  ClientCreateConditionalOrdersAccountInput,
  ClientCreateEscrowRequestInput,
  ClientDepositInput,
  ClientDelegateTraderInput,
  ClientHawkeyeBboInput,
  ClientHawkeyeTraderAssetInput,
  ClientHawkeyeTraderInput,
  ClientOnboardTraderDelegatedInput,
  ClientPlaceAttachedConditionalOrderInput,
  ClientPlaceLimitOrderWithConditionalsInput,
  ClientPlaceMarketOrderDelegatedInput,
  ClientPlaceOrderInput,
  ClientPlacePositionConditionalOrderInput,
  ClientPlaceStopLossInput,
  ClientSyncParentToChildInput,
  ClientTransferCollateralChildToParentInput,
  ClientTransferCollateralInput,
  ClientWithdrawInput,
  DepositIxsResult,
  PhoenixIxClient,
  ResolvedPlaceOrderContext,
  WithdrawIxsResult,
} from "./types";
import type {
  ImmediateOrCancelOrderPacket,
  LimitOrderPacket,
  PostOnlyOrderPacket,
} from "@/primitives";

export interface PhoenixIxResolvedMarketContext {
  assetId: number;
  marketAddress: MarketAddress;
  splineCollection: SplineCollectionAddress;
  tickSize?: number;
  baseLotsDecimals?: number;
}

export interface PhoenixIxExchangeInstructionAccounts {
  phoenixProgramAddress: PhoenixProgramAddress;
  logAuthorityAddress: LogAuthorityAddress;
  globalConfigurationAddress: GlobalConfigurationAddress;
  canonicalMint: MintAddress;
  usdcMint: MintAddress;
  perpAssetMap: PerpAssetMapAddress;
  globalVault: GlobalVaultAddress;
  withdrawQueue: WithdrawQueueAddress;
  globalTraderIndex: GlobalTraderIndexAddressArray;
  activeTraderBuffer: ActiveTraderBufferAddressArray;
}

export interface PhoenixIxEmberAccounts {
  emberState: EmberStateAddress;
  emberVault: EmberVaultAddress;
}

export interface PhoenixIxOperationContext {
  orderPackets: PhoenixOrderPacketBuilders;
  phoenixProgramAddress: PhoenixProgramAddress;
  resolvePlaceOrderContext: (params: {
    authority: Authority;
    positionAuthority?: Authority;
    symbol: Symbol;
    traderPdaIndex?: number;
    traderSubaccountIndex?: number;
  }) => Promise<ResolvedPlaceOrderContext>;
  resolveMarketContext: (
    symbol: Symbol
  ) => Promise<PhoenixIxResolvedMarketContext>;
  resolveExchangeInstructionAccounts: () => Promise<PhoenixIxExchangeInstructionAccounts>;
  resolveTraderAccount: (params: {
    authority: Authority;
    traderPdaIndex?: number;
    traderSubaccountIndex?: number;
  }) => Promise<TraderAddress>;
  resolveTraderTokenAccounts: (
    authority: Authority,
    params: {
      canonicalMint: MintAddress;
      usdcMint: MintAddress;
    }
  ) => Promise<{
    phoenixTokenAccount: TokenAccountAddress;
    usdcTokenAccount: TokenAccountAddress;
  }>;
  resolveEmberAccounts: () => Promise<PhoenixIxEmberAccounts>;
  resolveLogAuthorityAddress: () => Promise<LogAuthorityAddress>;
  resolveGlobalConfigurationAddress: () => Promise<GlobalConfigurationAddress>;
  resolveEscrowAddress: (authority: Address) => Promise<Address>;
  resolvePermissionAddress: (params: {
    permissionAuthority: Address;
    delegatedKey: Address;
  }) => Promise<Address>;
  resolveStopLossAddress: (params: {
    traderAccount: TraderAddress;
    assetId: bigint;
  }) => Promise<Address>;
  /**
   * Optionally wrap a fee-collecting placement instruction with Flight.
   * `signer` is the wallet that signs the instruction; `usePositionAuthority`
   * declares that `signer` is the trader's position authority rather than
   * the trader account's owner, which makes the wrap append the
   * collateral-transfer tail accounts so Flight can collect the builder fee.
   * Conditional placements go through {@link maybeWrapConditionalOrderIx}
   * instead.
   */
  maybeWrapOrderIx: <TIx extends InstructionsWithAccountsAndData>(
    instruction: TIx,
    signer: Authority,
    usePositionAuthority?: boolean
  ) => Promise<TIx>;
  /**
   * Optionally wrap a conditional placement (stop-loss, position/attached
   * conditional orders) with Flight. Conditional placements never collect a
   * builder fee and Flight forwards their full account list into the inner
   * CPI — never append the tail; wrap as owner-signed regardless of
   * `positionAuthority`. Mirrors the API server's
   * `maybe_wrap_conditional_order_instruction_with_flight`.
   */
  maybeWrapConditionalOrderIx: <TIx extends InstructionsWithAccountsAndData>(
    instruction: TIx,
    authority: Authority
  ) => Promise<TIx>;
  accountExists: (address: Address) => Promise<boolean>;
}

/**
 * Effective wallet that signs a placement instruction, mirroring the API
 * server DTOs: `position_authority.unwrap_or(authority)` is the signer
 * (`traderWallet` is the delegated market order's spelling of the same
 * concept). The trader PDA always derives from `authority` (the owner), and
 * `usePositionAuthority` — the single derivation of "the signer is not the
 * owner" — routes the Flight wrap through the position-authority path.
 */
const resolveOrderSigner = (params: {
  authority: Authority;
  positionAuthority?: Authority;
  traderWallet?: Authority;
}): { signer: Authority; usePositionAuthority: boolean } => {
  const signer =
    params.traderWallet ?? params.positionAuthority ?? params.authority;
  return { signer, usePositionAuthority: signer !== params.authority };
};

const priceToTicks = (
  priceUsd: bigint | number,
  tickSize: number,
  baseLotsDecimals: number
): bigint => {
  const price = typeof priceUsd === "bigint" ? Number(priceUsd) : priceUsd;
  const priceTicks =
    (price * 1_000_000) / (tickSize * Math.pow(10, baseLotsDecimals));
  return BigInt(Math.floor(priceTicks));
};

const cancelOrderPriceInTicks = (
  order: ClientCancelOrdersByIdInput["orders"][number],
  market: Pick<PhoenixIxResolvedMarketContext, "tickSize" | "baseLotsDecimals">
) => {
  if ("priceInTicks" in order && order.priceInTicks !== undefined) {
    return ticks(order.priceInTicks);
  }
  if (!("price" in order)) {
    throw new Error("Cancel order requires priceInTicks or price");
  }

  const { tickSize, baseLotsDecimals } = market;
  if (tickSize === undefined) {
    throw new Error("Market metadata is missing tick size");
  }
  if (baseLotsDecimals === undefined) {
    throw new Error("Market metadata is missing base lot decimals");
  }

  return ticks(priceToTicks(order.price, tickSize, baseLotsDecimals));
};

export const createPhoenixIxOperations = (
  context: PhoenixIxOperationContext
): PhoenixIxClient => {
  const buildWrappedOrder = async <
    TPacket extends
      | LimitOrderPacket
      | ImmediateOrCancelOrderPacket
      | PostOnlyOrderPacket,
    TInput extends ClientPlaceOrderInput<TPacket>,
    TIx extends InstructionsWithAccountsAndData,
  >(
    params: TInput,
    buildInstruction: (
      input: ResolvedPlaceOrderContext & { orderPacket: TPacket } & TInput
    ) => TIx
  ): Promise<TIx> => {
    const input = {
      ...(await context.resolvePlaceOrderContext(params)),
      ...params,
    };
    const { signer, usePositionAuthority } = resolveOrderSigner(params);
    return context.maybeWrapOrderIx(
      buildInstruction(input),
      signer,
      usePositionAuthority
    );
  };

  const buildWrappedLimitOrder = (
    params: ClientPlaceOrderInput<LimitOrderPacket>
  ) => buildWrappedOrder(params, buildPlaceLimitOrderIxResolved);

  const buildWrappedMarketOrder = (
    params: ClientPlaceOrderInput<ImmediateOrCancelOrderPacket>
  ) => buildWrappedOrder(params, buildPlaceMarketOrderIxResolved);

  const buildWrappedMarketOrderDelegated = (
    params: ClientPlaceMarketOrderDelegatedInput
  ) => buildWrappedOrder(params, buildPlaceMarketOrderDelegatedIxResolved);

  const buildWrappedPostOnlyOrder = (
    params: ClientPlaceOrderInput<PostOnlyOrderPacket>
  ) => buildWrappedOrder(params, buildPlacePostOnlyOrderIxResolved);

  const resolveConditionalOrdersAccount = async (
    traderAccount: TraderAddress
  ) =>
    getPhoenixConditionalOrdersAddress({
      traderAccount,
      phoenixProgramAddress: context.phoenixProgramAddress,
    });

  const resolveHawkeyeBaseAccounts = async () => {
    const exchangeAccounts = await context.resolveExchangeInstructionAccounts();
    return {
      phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
      globalConfigurationAddress: exchangeAccounts.globalConfigurationAddress,
      globalTraderIndex: exchangeAccounts.globalTraderIndex,
      activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
      perpAssetMap: exchangeAccounts.perpAssetMap,
    };
  };

  const resolveHawkeyeTraderAccounts = async (
    params: ClientHawkeyeTraderInput
  ) => ({
    ...(await resolveHawkeyeBaseAccounts()),
    traderAccount:
      params.traderAccount !== undefined
        ? params.traderAccount
        : await context.resolveTraderAccount({
            authority: params.authority,
            traderPdaIndex: params.traderPdaIndex,
            traderSubaccountIndex: params.traderSubaccountIndex,
          }),
  });

  const resolveHawkeyeAssetId = async (
    params: ClientHawkeyeTraderAssetInput
  ): Promise<number> => {
    if (params.assetId !== undefined) {
      return params.assetId;
    }
    if (!params.symbol) {
      throw new Error("symbol or assetId is required for this Hawkeye view");
    }
    return (await context.resolveMarketContext(params.symbol)).assetId;
  };

  const resolveHawkeyeBboAccounts = async (params: ClientHawkeyeBboInput) => {
    const [baseAccounts, market] = await Promise.all([
      resolveHawkeyeBaseAccounts(),
      context.resolveMarketContext(params.symbol),
    ]);
    return {
      ...baseAccounts,
      orderbook: market.marketAddress,
      splineCollection: market.splineCollection,
    };
  };

  const buildCreateConditionalOrdersAccount = async (
    params: ClientCreateConditionalOrdersAccountInput
  ): Promise<CreateConditionalOrdersAccountIx> => {
    const [logAuthorityAddress, globalConfigurationAddress, traderAccount] =
      await Promise.all([
        context.resolveLogAuthorityAddress(),
        context.resolveGlobalConfigurationAddress(),
        context.resolveTraderAccount({
          authority: params.authority,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: params.traderSubaccountIndex,
        }),
      ]);

    return buildCreateConditionalOrdersAccountIx({
      programAddress: context.phoenixProgramAddress,
      logAuthorityAddress,
      globalConfigurationAddress,
      payer: params.payer ?? params.authority,
      traderWallet: params.positionAuthority ?? params.authority,
      traderAccount,
      traderConditionalOrders:
        await resolveConditionalOrdersAccount(traderAccount),
      capacity: params.capacity ?? 32,
    });
  };

  const buildWrappedPositionConditionalOrder = async (
    params: ClientPlacePositionConditionalOrderInput
  ): Promise<PlacePositionConditionalOrderIx> => {
    const [exchangeAccounts, market, traderAccount] = await Promise.all([
      context.resolveExchangeInstructionAccounts(),
      context.resolveMarketContext(params.symbol),
      context.resolveTraderAccount({
        authority: params.authority,
        traderPdaIndex: params.traderPdaIndex,
        traderSubaccountIndex: params.traderSubaccountIndex,
      }),
    ]);

    return context.maybeWrapConditionalOrderIx(
      buildPlacePositionConditionalOrderIx({
        programAddress: exchangeAccounts.phoenixProgramAddress,
        logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
        globalConfigurationAddress: exchangeAccounts.globalConfigurationAddress,
        payer: params.payer ?? params.authority,
        traderAccount,
        perpAssetMap: exchangeAccounts.perpAssetMap,
        globalTraderIndex: exchangeAccounts.globalTraderIndex,
        activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
        orderbook: market.marketAddress,
        splineCollection: market.splineCollection,
        traderWallet: params.positionAuthority ?? params.authority,
        traderConditionalOrders:
          await resolveConditionalOrdersAccount(traderAccount),
        assetId: market.assetId,
        greaterTriggerOrder: normalizeTriggerOrderParams(
          params.greaterTriggerOrder
        ),
        lessTriggerOrder: normalizeTriggerOrderParams(params.lessTriggerOrder),
        sizeBaseLots: params.sizeBaseLots ?? null,
        sizePercent: params.sizePercent ?? null,
      }),
      params.authority
    );
  };

  const buildWrappedAttachedConditionalOrder = async (
    params: ClientPlaceAttachedConditionalOrderInput
  ): Promise<PlaceAttachedConditionalOrderIx> => {
    const [exchangeAccounts, market, traderAccount] = await Promise.all([
      context.resolveExchangeInstructionAccounts(),
      context.resolveMarketContext(params.symbol),
      context.resolveTraderAccount({
        authority: params.authority,
        traderPdaIndex: params.traderPdaIndex,
        traderSubaccountIndex: params.traderSubaccountIndex,
      }),
    ]);

    return context.maybeWrapConditionalOrderIx(
      buildPlaceAttachedConditionalOrderIx({
        programAddress: exchangeAccounts.phoenixProgramAddress,
        logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
        globalConfigurationAddress: exchangeAccounts.globalConfigurationAddress,
        traderAccount,
        traderWallet: params.positionAuthority ?? params.authority,
        orderbook: market.marketAddress,
        traderConditionalOrders:
          await resolveConditionalOrdersAccount(traderAccount),
        payer: params.payer ?? params.authority,
        globalTraderIndex: exchangeAccounts.globalTraderIndex,
        activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
        orderId: params.orderId,
        assetId: market.assetId,
        greaterTriggerOrder: normalizeTriggerOrderParams(
          params.greaterTriggerOrder
        ),
        lessTriggerOrder: normalizeTriggerOrderParams(params.lessTriggerOrder),
      }),
      params.authority
    );
  };

  const buildWrappedLimitOrderWithConditionals = async (
    params: ClientPlaceLimitOrderWithConditionalsInput
  ): Promise<PlaceLimitOrderWithConditionalsIx> => {
    const { signer, usePositionAuthority } = resolveOrderSigner(params);
    const [exchangeAccounts, market, traderAccount] = await Promise.all([
      context.resolveExchangeInstructionAccounts(),
      context.resolveMarketContext(params.symbol),
      context.resolveTraderAccount({
        authority: params.authority,
        traderPdaIndex: params.traderPdaIndex,
        traderSubaccountIndex: params.traderSubaccountIndex,
      }),
    ]);

    return context.maybeWrapOrderIx(
      buildPlaceLimitOrderWithConditionalsIx({
        programAddress: exchangeAccounts.phoenixProgramAddress,
        logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
        globalConfigurationAddress: exchangeAccounts.globalConfigurationAddress,
        traderWallet: signer,
        traderAccount,
        perpAssetMap: exchangeAccounts.perpAssetMap,
        globalTraderIndex: exchangeAccounts.globalTraderIndex,
        activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
        orderbook: market.marketAddress,
        splineCollection: market.splineCollection,
        payer: params.payer ?? params.authority,
        traderConditionalOrders:
          await resolveConditionalOrdersAccount(traderAccount),
        orderPacket: params.orderPacket,
        slot: params.slot,
        greaterTriggerOrder: normalizeTriggerOrderParams(
          params.greaterTriggerOrder
        ),
        lessTriggerOrder: normalizeTriggerOrderParams(params.lessTriggerOrder),
      }),
      signer,
      usePositionAuthority
    );
  };

  return {
    orderPackets: context.orderPackets,
    buildCancelAll: async (params: ClientCancelAllInput) =>
      buildCancelAllIxResolved(await context.resolvePlaceOrderContext(params)),
    buildCancelOrdersById: async (params: ClientCancelOrdersByIdInput) => {
      const [exchangeAccounts, market, traderAccount] = await Promise.all([
        context.resolveExchangeInstructionAccounts(),
        context.resolveMarketContext(params.symbol),
        context.resolveTraderAccount({
          authority: params.authority,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: params.traderSubaccountIndex,
        }),
      ]);

      return buildCancelOrdersByIdIxResolved({
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
          perpAssetMap: exchangeAccounts.perpAssetMap,
          globalTraderIndex: exchangeAccounts.globalTraderIndex,
          activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
        },
        market: {
          marketAddress: market.marketAddress,
          splineCollection: market.splineCollection,
        },
        trader: {
          authority: params.authority,
          positionAuthority: params.positionAuthority,
          traderAccount,
        },
        orderIds: params.orders.map((order) => ({
          nodePointer: null,
          orderId: {
            priceInTicks: cancelOrderPriceInTicks(order, market),
            orderSequenceNumber: BigInt(order.orderSequenceNumber),
          },
        })),
      });
    },
    buildCancelUpTo: async (params: ClientCancelUpToInput) =>
      buildCancelUpToIxResolved({
        ...(await context.resolvePlaceOrderContext(params)),
        side: params.side,
        numOrdersToCancel: params.numOrdersToCancel,
        tickLimit: params.tickLimit,
      }),
    buildUncrossCrank: async (params: ClientUncrossCrankInput) => {
      const [exchangeAccounts, market] = await Promise.all([
        context.resolveExchangeInstructionAccounts(),
        context.resolveMarketContext(params.symbol),
      ]);

      return buildUncrossCrankIxResolved({
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
          perpAssetMap: exchangeAccounts.perpAssetMap,
          globalTraderIndex: exchangeAccounts.globalTraderIndex,
          activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
        },
        market: {
          marketAddress: market.marketAddress,
          splineCollection: market.splineCollection,
        },
        matchLimit: params.matchLimit,
      });
    },
    buildCancelStopLoss: async (params: ClientCancelStopLossInput) => {
      const [exchangeAccounts, market, traderAccount] = await Promise.all([
        context.resolveExchangeInstructionAccounts(),
        context.resolveMarketContext(params.symbol),
        context.resolveTraderAccount({
          authority: params.authority,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: params.traderSubaccountIndex,
        }),
      ]);
      const stopLossAccount = await context.resolveStopLossAddress({
        traderAccount,
        assetId: BigInt(market.assetId),
      });

      return buildCancelStopLossIxResolved({
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
        },
        trader: {
          authority: params.authority,
          funder: params.funder,
          traderAccount,
          stopLossAccount,
        },
        executionDirection: params.executionDirection,
      });
    },
    buildCreateConditionalOrdersAccount,
    buildCreateEscrowRequest: async (
      params: ClientCreateEscrowRequestInput
    ) => {
      const exchangeAccounts =
        await context.resolveExchangeInstructionAccounts();
      const senderPdaIndex = params.senderPdaIndex ?? 0;
      const senderSubaccountIndex = params.senderSubaccountIndex ?? 0;
      const receiverPdaIndex = params.receiverPdaIndex ?? 0;
      const receiverSubaccountIndex = params.receiverSubaccountIndex ?? 0;

      const [
        senderTraderAccount,
        receiverTraderAccount,
        receiverEscrow,
        permissionAccount,
      ] = await Promise.all([
        context.resolveTraderAccount({
          authority: params.senderAuthority,
          traderPdaIndex: senderPdaIndex,
          traderSubaccountIndex: senderSubaccountIndex,
        }),
        context.resolveTraderAccount({
          authority: params.receiverAuthority,
          traderPdaIndex: receiverPdaIndex,
          traderSubaccountIndex: receiverSubaccountIndex,
        }),
        context.resolveEscrowAddress(params.receiverAuthority),
        context.resolvePermissionAddress({
          permissionAuthority: params.receiverAuthority,
          delegatedKey: params.senderAuthority,
        }),
      ]);

      return buildCreateEscrowRequestIxResolved({
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
          perpAssetMap: exchangeAccounts.perpAssetMap,
          globalTraderIndex: exchangeAccounts.globalTraderIndex,
          activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
        },
        sender: {
          authority: params.senderAuthority,
          traderAccount: senderTraderAccount,
          traderPdaIndex: senderPdaIndex,
          traderSubaccountIndex: senderSubaccountIndex,
        },
        receiver: {
          authority: params.receiverAuthority,
          traderAccount: receiverTraderAccount,
          escrowAddress: receiverEscrow,
          permissionAddress: permissionAccount,
          traderPdaIndex: receiverPdaIndex,
          traderSubaccountIndex: receiverSubaccountIndex,
        },
        actions: params.actions,
        lastValidSlot: params.lastValidSlot,
      });
    },
    buildDelegateTrader: async (params: ClientDelegateTraderInput) =>
      buildDelegateTraderIxResolved({
        exchange: {
          phoenixProgramAddress: context.phoenixProgramAddress,
          logAuthorityAddress: await context.resolveLogAuthorityAddress(),
          globalConfigurationAddress:
            await context.resolveGlobalConfigurationAddress(),
        },
        trader: {
          authority: params.traderWallet,
          traderAccount: await context.resolveTraderAccount({
            authority: params.traderWallet,
            traderPdaIndex: params.traderPdaIndex,
            traderSubaccountIndex: params.traderSubaccountIndex,
          }),
        },
        newPositionAuthority: params.newPositionAuthority,
      }),
    buildOnboardTraderDelegated: async (
      params: ClientOnboardTraderDelegatedInput
    ) => {
      const exchangeAccounts =
        await context.resolveExchangeInstructionAccounts();
      const traderAccount = await context.resolveTraderAccount({
        authority: params.traderAuthority,
        traderPdaIndex: params.traderPdaIndex,
        traderSubaccountIndex: params.traderSubaccountIndex,
      });

      return buildOnboardTraderDelegatedIxResolved({
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
          globalTraderIndex: exchangeAccounts.globalTraderIndex,
          activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
        },
        trader: {
          authority: params.authority,
          permissionAccount: params.permissionAccount,
          traderAccount,
        },
      });
    },
    buildPlaceLimitOrder: buildWrappedLimitOrder,
    buildPlaceMarketOrder: buildWrappedMarketOrder,
    buildPlaceMarketOrderDelegated: buildWrappedMarketOrderDelegated,
    buildPlacePositionConditionalOrder: buildWrappedPositionConditionalOrder,
    buildPlaceAttachedConditionalOrder: buildWrappedAttachedConditionalOrder,
    buildPlaceLimitOrderWithConditionals:
      buildWrappedLimitOrderWithConditionals,
    buildPlacePostOnlyOrder: buildWrappedPostOnlyOrder,
    placeLimitOrder: buildWrappedLimitOrder,
    placeMarketOrder: buildWrappedMarketOrder,
    placeMarketOrderDelegated: buildWrappedMarketOrderDelegated,
    placePositionConditionalOrder: buildWrappedPositionConditionalOrder,
    placePostOnlyOrder: buildWrappedPostOnlyOrder,
    buildDepositFunds: async (params: ClientDepositInput) => {
      const exchangeAccounts =
        await context.resolveExchangeInstructionAccounts();
      const [traderAccount, { phoenixTokenAccount }] = await Promise.all([
        context.resolveTraderAccount({
          authority: params.authority,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: params.traderSubaccountIndex,
        }),
        context.resolveTraderTokenAccounts(params.authority, {
          canonicalMint: exchangeAccounts.canonicalMint,
          usdcMint: exchangeAccounts.usdcMint,
        }),
      ]);

      return buildDepositFundsIxResolved({
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
          canonicalMint: exchangeAccounts.canonicalMint,
          globalVault: exchangeAccounts.globalVault,
          globalTraderIndex: exchangeAccounts.globalTraderIndex,
          activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
        },
        trader: {
          authority: params.authority,
          traderAccount,
          traderTokenAccount: phoenixTokenAccount,
          permissionAddress: params.permissionAddress,
        },
        amount: params.amount,
      });
    },
    buildWithdrawFunds: async (params: ClientWithdrawInput) => {
      const exchangeAccounts =
        await context.resolveExchangeInstructionAccounts();
      const [traderAccount, { phoenixTokenAccount }] = await Promise.all([
        context.resolveTraderAccount({
          authority: params.authority,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: params.traderSubaccountIndex,
        }),
        context.resolveTraderTokenAccounts(params.authority, {
          canonicalMint: exchangeAccounts.canonicalMint,
          usdcMint: exchangeAccounts.usdcMint,
        }),
      ]);

      return buildWithdrawFundsIxResolved({
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
          canonicalMint: exchangeAccounts.canonicalMint,
          perpAssetMap: exchangeAccounts.perpAssetMap,
          globalVault: exchangeAccounts.globalVault,
          withdrawQueue: exchangeAccounts.withdrawQueue,
          globalTraderIndex: exchangeAccounts.globalTraderIndex,
          activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
        },
        trader: {
          authority: params.authority,
          traderAccount,
          destinationTokenAccount: phoenixTokenAccount,
        },
        amount: params.amount,
      });
    },
    buildTransferCollateral: async (params: ClientTransferCollateralInput) => {
      const exchangeAccounts =
        await context.resolveExchangeInstructionAccounts();
      const [srcTraderAccount, dstTraderAccount] = await Promise.all([
        context.resolveTraderAccount({
          authority: params.authority,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: params.srcSubaccountIndex,
        }),
        context.resolveTraderAccount({
          authority: params.authority,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: params.dstSubaccountIndex,
        }),
      ]);

      return buildTransferCollateralIxResolved({
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
          perpAssetMap: exchangeAccounts.perpAssetMap,
          globalTraderIndex: exchangeAccounts.globalTraderIndex,
          activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
        },
        trader: {
          authority: params.authority,
          positionAuthority: params.positionAuthority,
          permissionAddress: params.permissionAddress,
          srcTraderAccount,
          dstTraderAccount,
        },
        amount: params.amount,
      });
    },
    buildTransferCollateralChildToParent: async (
      params: ClientTransferCollateralChildToParentInput
    ) => {
      const exchangeAccounts =
        await context.resolveExchangeInstructionAccounts();
      const [childTraderAccount, parentTraderAccount] = await Promise.all([
        context.resolveTraderAccount({
          authority: params.authority,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: params.childSubaccountIndex,
        }),
        context.resolveTraderAccount({
          authority: params.authority,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: 0,
        }),
      ]);

      return buildTransferCollateralChildToParentIxResolved({
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
          perpAssetMap: exchangeAccounts.perpAssetMap,
          globalTraderIndex: exchangeAccounts.globalTraderIndex,
          activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
        },
        trader: {
          authority: params.authority,
          positionAuthority: params.positionAuthority,
          childTraderAccount,
          parentTraderAccount,
        },
      });
    },
    buildEmberDeposit: async (params: ClientDepositInput) => {
      const [exchangeAccounts, emberAccounts] = await Promise.all([
        context.resolveExchangeInstructionAccounts(),
        context.resolveEmberAccounts(),
      ]);
      const { phoenixTokenAccount, usdcTokenAccount } =
        await context.resolveTraderTokenAccounts(params.authority, {
          canonicalMint: exchangeAccounts.canonicalMint,
          usdcMint: exchangeAccounts.usdcMint,
        });

      return buildEmberDepositIxResolved({
        exchange: {
          usdcMint: exchangeAccounts.usdcMint,
          canonicalMint: exchangeAccounts.canonicalMint,
          emberState: emberAccounts.emberState,
          emberVault: emberAccounts.emberVault,
        },
        trader: {
          authority: params.authority,
          usdcTokenAccount,
          phoenixTokenAccount,
        },
        amount: params.amount,
      });
    },
    buildEmberWithdraw: async (params: ClientWithdrawInput) => {
      const [exchangeAccounts, emberAccounts] = await Promise.all([
        context.resolveExchangeInstructionAccounts(),
        context.resolveEmberAccounts(),
      ]);
      const { phoenixTokenAccount, usdcTokenAccount } =
        await context.resolveTraderTokenAccounts(params.authority, {
          canonicalMint: exchangeAccounts.canonicalMint,
          usdcMint: exchangeAccounts.usdcMint,
        });

      return buildEmberWithdrawIxResolved({
        exchange: {
          usdcMint: exchangeAccounts.usdcMint,
          canonicalMint: exchangeAccounts.canonicalMint,
          emberState: emberAccounts.emberState,
          emberVault: emberAccounts.emberVault,
        },
        trader: {
          authority: params.authority,
          usdcTokenAccount,
          phoenixTokenAccount,
        },
        amount: params.amount,
      });
    },
    buildPlaceStopLoss: async (params: ClientPlaceStopLossInput) => {
      const [exchangeAccounts, market, traderAccount] = await Promise.all([
        context.resolveExchangeInstructionAccounts(),
        context.resolveMarketContext(params.symbol),
        context.resolveTraderAccount({
          authority: params.authority,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: params.traderSubaccountIndex,
        }),
      ]);
      const stopLossAccount = await context.resolveStopLossAddress({
        traderAccount,
        assetId: BigInt(market.assetId),
      });
      const triggerOrder = buildTriggerOrderParams({
        triggerDirection: params.executionDirection,
        tradeSide: params.tradeSide,
        orderKind: params.orderKind,
        triggerPrice: ticks(params.triggerPrice),
        executionPrice:
          params.executionPrice == null
            ? params.executionPrice
            : ticks(params.executionPrice),
        slippageBps: params.slippageBps,
      });

      return context.maybeWrapConditionalOrderIx(
        buildPlaceStopLossIxResolved({
          exchange: {
            phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
            logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
            globalConfigurationAddress:
              exchangeAccounts.globalConfigurationAddress,
            perpAssetMap: exchangeAccounts.perpAssetMap,
            globalTraderIndex: exchangeAccounts.globalTraderIndex,
            activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
          },
          market: {
            marketAddress: market.marketAddress,
            splineCollection: market.splineCollection,
          },
          trader: {
            authority: params.authority,
            funder: params.payer,
            positionAuthority: params.positionAuthority,
            traderAccount,
          },
          stopLossAccount,
          triggerPrice: triggerOrder.triggerPrice,
          executionPrice: triggerOrder.executionPrice,
          tradeSide: triggerOrder.tradeSide,
          executionDirection: triggerOrder.triggerDirection,
          orderKind: triggerOrder.orderKind,
        }),
        params.authority
      );
    },
    buildRegisterTrader: async (params: BuildRegisterTraderParams) => {
      const traderPdaIndex = params.traderPdaIndex ?? 0;
      if (traderPdaIndex !== 0) {
        throw new Error("Non-zero traderPdaIndex is not yet supported.");
      }

      const traderSubaccountIndex =
        params.marginType === MarginType.Isolated
          ? params.traderSubaccountIndex
          : 0;

      if (params.marginType === MarginType.Isolated) {
        if (traderSubaccountIndex === undefined) {
          throw new Error(
            "Trader subaccount index is required for isolated margin"
          );
        }
        if (traderSubaccountIndex === 0) {
          throw new Error(
            "Trader subaccount index 0 is reserved for cross margin"
          );
        }
      }

      if ((traderSubaccountIndex ?? 0) > MAX_SUBACCOUNTS) {
        throw new Error("Trader subaccount index is out of bounds");
      }

      const traderAccount = await context.resolveTraderAccount({
        authority: params.authority,
        traderPdaIndex,
        traderSubaccountIndex: traderSubaccountIndex ?? 0,
      });

      if (await context.accountExists(traderAccount)) {
        throw new Error(
          params.marginType === MarginType.Isolated
            ? "Isolated margin trader account already exists"
            : "Cross-margin trader account already exists"
        );
      }

      return buildRegisterTraderIxResolved({
        exchange: {
          phoenixProgramAddress: context.phoenixProgramAddress,
          logAuthorityAddress: await context.resolveLogAuthorityAddress(),
          globalConfigurationAddress:
            await context.resolveGlobalConfigurationAddress(),
        },
        trader: {
          payer: params.feePayer ?? params.authority,
          authority: params.authority,
          traderAccount,
        },
        maxPositions: BigInt(toMaxPositions(params.marginType)),
        traderPreferenceBits: params.traderPreferenceBits,
        traderPreferences: params.traderPreferences,
        disableCollateralSweep: params.disableCollateralSweep,
        traderPdaIndex,
        traderSubaccountIndex: traderSubaccountIndex ?? 0,
      });
    },
    buildSyncParentToChild: async (params: ClientSyncParentToChildInput) => {
      const exchangeAccounts =
        await context.resolveExchangeInstructionAccounts();
      const [parentTraderAccount, childTraderAccount] = await Promise.all([
        context.resolveTraderAccount({
          authority: params.traderWallet,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: 0,
        }),
        context.resolveTraderAccount({
          authority: params.traderWallet,
          traderPdaIndex: params.traderPdaIndex,
          traderSubaccountIndex: params.traderSubaccountIndex,
        }),
      ]);

      return buildSyncParentToChildIxResolved({
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
          globalTraderIndex: exchangeAccounts.globalTraderIndex,
        },
        trader: {
          authority: params.traderWallet,
          parentTraderAccount,
          childTraderAccount,
        },
      });
    },
    buildDepositIxs: async (
      params: ClientDepositInput
    ): Promise<DepositIxsResult> => {
      const [exchangeAccounts, emberAccounts, traderAccount] =
        await Promise.all([
          context.resolveExchangeInstructionAccounts(),
          context.resolveEmberAccounts(),
          context.resolveTraderAccount({
            authority: params.authority,
            traderPdaIndex: params.traderPdaIndex,
            traderSubaccountIndex: params.traderSubaccountIndex,
          }),
        ]);
      const { phoenixTokenAccount, usdcTokenAccount } =
        await context.resolveTraderTokenAccounts(params.authority, {
          canonicalMint: exchangeAccounts.canonicalMint,
          usdcMint: exchangeAccounts.usdcMint,
        });

      return buildDepositIxsResolved({
        feePayer: params.feePayer,
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
          canonicalMint: exchangeAccounts.canonicalMint,
          usdcMint: exchangeAccounts.usdcMint,
          globalVault: exchangeAccounts.globalVault,
          globalTraderIndex: exchangeAccounts.globalTraderIndex,
          activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
          emberState: emberAccounts.emberState,
          emberVault: emberAccounts.emberVault,
        },
        trader: {
          authority: params.authority,
          traderAccount,
          usdcTokenAccount,
          phoenixTokenAccount,
        },
        amount: params.amount,
      });
    },
    buildWithdrawIxs: async (
      params: ClientWithdrawInput
    ): Promise<WithdrawIxsResult> => {
      const [exchangeAccounts, emberAccounts, traderAccount] =
        await Promise.all([
          context.resolveExchangeInstructionAccounts(),
          context.resolveEmberAccounts(),
          context.resolveTraderAccount({
            authority: params.authority,
            traderPdaIndex: params.traderPdaIndex,
            traderSubaccountIndex: params.traderSubaccountIndex,
          }),
        ]);
      const { phoenixTokenAccount, usdcTokenAccount } =
        await context.resolveTraderTokenAccounts(params.authority, {
          canonicalMint: exchangeAccounts.canonicalMint,
          usdcMint: exchangeAccounts.usdcMint,
        });

      return buildWithdrawIxsResolved({
        feePayer: params.feePayer,
        exchange: {
          phoenixProgramAddress: exchangeAccounts.phoenixProgramAddress,
          logAuthorityAddress: exchangeAccounts.logAuthorityAddress,
          globalConfigurationAddress:
            exchangeAccounts.globalConfigurationAddress,
          canonicalMint: exchangeAccounts.canonicalMint,
          usdcMint: exchangeAccounts.usdcMint,
          perpAssetMap: exchangeAccounts.perpAssetMap,
          globalVault: exchangeAccounts.globalVault,
          withdrawQueue: exchangeAccounts.withdrawQueue,
          globalTraderIndex: exchangeAccounts.globalTraderIndex,
          activeTraderBuffer: exchangeAccounts.activeTraderBuffer,
          emberState: emberAccounts.emberState,
          emberVault: emberAccounts.emberVault,
        },
        trader: {
          authority: params.authority,
          traderAccount,
          usdcTokenAccount,
          phoenixTokenAccount,
        },
        amount: params.amount,
      });
    },
    buildHawkeyeViewMargin: async (params: ClientHawkeyeTraderInput) =>
      buildHawkeyeViewMarginIx(await resolveHawkeyeTraderAccounts(params)),
    buildHawkeyeViewMarginForAsset: async (
      params: ClientHawkeyeTraderAssetInput
    ) =>
      buildHawkeyeViewMarginForAssetIx({
        ...(await resolveHawkeyeTraderAccounts(params)),
        assetId: await resolveHawkeyeAssetId(params),
      }),
    buildHawkeyeViewLiquidationPrice: async (
      params: ClientHawkeyeTraderAssetInput
    ) =>
      buildHawkeyeViewLiquidationPriceIx({
        ...(await resolveHawkeyeTraderAccounts(params)),
        assetId: await resolveHawkeyeAssetId(params),
      }),
    buildHawkeyeViewBbo: async (params: ClientHawkeyeBboInput) =>
      buildHawkeyeViewBboIx(await resolveHawkeyeBboAccounts(params)),
    buildHawkeyeViewFunding: async (params: ClientHawkeyeTraderAssetInput) =>
      buildHawkeyeViewFundingIx({
        ...(await resolveHawkeyeTraderAccounts(params)),
        assetId: await resolveHawkeyeAssetId(params),
      }),
  };
};
