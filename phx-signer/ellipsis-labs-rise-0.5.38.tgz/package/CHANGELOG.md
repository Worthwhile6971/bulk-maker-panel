# Changelog

Entries are drafted by Phoenix Rise sync PRs. Review and edit each
entry in this repo before merging.

## v0.5.38 - 2026-09-29

Source Phoenix commit: `b50781149f884f35dc5e4bca07782a6e6b8e461c`

### Summary

- Bumps the `@ellipsis-labs/rise` TypeScript package from 0.5.37 to 0.5.38.
- Updates the lockfile. Transitive `@solana/*` packages move to 8.3.0, and `@solana-program/system` and `@solana-program/token` move to 0.14.1 and 0.16.1. These `@solana-program/*` peers now require `@solana/kit` `^8.0.0`.
- Updates the `litesvm` dev dependency from 1.0.0 to 1.4.1. It is a development dependency only.

### Breaking Changes

- None identified in the synced diff. `ts/package.json` shows only the version bump and the `litesvm` dev dependency change. No public exports, types, or runtime entrypoints changed in the visible diff.

### Consumer Notes

- The lockfile changes affect this repo's own dependency resolution, not the published package's dependency ranges. The `package.json` diff shows no changes to runtime `dependencies` or `peerDependencies`.
- Consumers who also install `@solana-program/system` or `@solana-program/token` alongside this package should check that their `@solana/kit` version matches those packages' peer requirement (`^8.0.0`). This applies only if they use the versions in this lockfile.
- The diff was truncated, so this entry is limited to the visible `package.json` and lockfile changes.

## v0.5.37 - 2026-09-29

Source Phoenix commit: `f00817047214aaf92ece9d8a2aa56e2c7a907fd8`

```markdown
### Summary

- Added an optional `earningsDates` field to `MarketPublicMetadata`. It is a sorted list of earnings timestamps as ISO 8601 datetime strings. Date-only values use midnight UTC. Filter the list against the current time to get upcoming dates.
- `MarketPublicMetadataSchema` now validates `earningsDates` as an array of datetime strings, and offsets are allowed. The strict exchange snapshot and metadata delta paths accept the field.
- The exchange cache treats changes to `earningsDates` as metadata changes. Adding, changing, or clearing earnings dates through a metadata delta produces a new metadata object, so selectors and subscribers see the update.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `earningsDates` is optional, so existing code that reads market metadata still compiles. Handle it being `undefined`, and handle an empty array when earnings dates are cleared.
- Strict-schema consumers that validate exchange payloads can now receive `earningsDates` without failing validation. Values that are not valid datetime strings will be rejected.
```

## v0.5.36 - 2026-09-29

Source Phoenix commit: `543c500e521060e7bee25280dbb7d10360bbc1d9`

### Summary

- Adds Hawkeye order-quote support. `buildHawkeyeViewOrderQuoteIx` builds a `view_order_quote` instruction from an `OrderPacket` (PostOnly, Limit or ImmediateOrCancel) and an optional `referencePriceTicks`. `decodeHawkeyeReturnData` now decodes the result as `HawkeyeOrderQuoteReturn`. It includes fills, fees, posted size, average price, slippage, outcome and rejection reason.
- Adds helpers `isHawkeyeOrderQuoteFullyFilled` and `getHawkeyeOrderQuoteNetQuoteLots`, plus new `HAWKEYE_ORDER_QUOTE_*` flag constants. The quote checks matching only, so an accepted quote doesn't confirm taker margin or permissions.
- `encodeHawkeyeSimulationTransaction` accepts optional `preInstructions`. They run after the compute-budget instruction and before the Hawkeye view, for example to allocate the scratch buffer an order quote needs.
- Exports the `OrderPacket` type and `getOrderPacketCodec`, `getOrderPacketDecoder` and `getOrderPacketEncoder` from the public SDK. The `getConditionalOrderPacket*` codecs and the `ConditionalOrderPacket` type are now aliases of these, and their encoding is unchanged.
- Trader state spot collateral rows gain an optional `maxBalance`: the trader's effective per-trader cap, in native units, as a decimal string. Servers that predate the field omit it.
- `nativeSolCollateralHeadroomLamports` and `attributedNativeSolDepositLamports` accept an optional `traderMaxBalanceLamports`. Pass `BigInt(row.maxBalance)` from the SOL row so headroom uses the trader's own cap rather than the asset-wide `maxPerTraderBalance`.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- Before calling `buildHawkeyeViewOrderQuoteIx`, allocate the writable, zero-lamport Hawkeye-owned scratch account earlier in the same transaction. Pass that allocation through `preInstructions` when simulating. Hawkeye closes the buffer on success.
- Order quotes don't support `cancelExisting`. Expected matching rejections come back as a quote with zero retained fills, fees and posts, so check `outcome` and `rejectionReason`.
- `HawkeyeReturnData` and `HawkeyeViewKind` now include the `orderQuote` / `view_order_quote` variant. Code that switches exhaustively on these types needs a new case.
- If you size native SOL deposits, start passing `traderMaxBalanceLamports` from trader state's `maxBalance`. Without it, headroom falls back to the asset-wide cap and can differ from what the program credits when the trader's cap is different. Omit it only when the trader has no account yet.

## v0.5.35 - 2026-09-28

Source Phoenix commit: `fdaeef82f69e2b6672f7aba6eb8d8fc1755f13a6`

### Summary

- Adds Flight trader-onboarding support: new `flight.buildSetOnboarderSignerIx` and `flight.buildOnboardTraderIx` instruction builders, with codecs, param and account types, and matching discriminants. A third discriminant, `update_builder_onboarding`, is also registered, but no builder for it is exposed yet.
- Adds PDA helpers `getFlightTraderOnboardingAuthorityAddress` and `getFlightTraderOnboardingPermissionAddress`, plus the branded types `FlightTraderOnboardingAuthorityAddress` and `FlightTraderOnboardingPermissionAddress`.
- `BuilderState` now decodes four onboarding fields: `onboarderSignerPubkey`, `onboarderNumOnboardingRemaining`, `onboarderMakerFeeDiscount` and `onboarderTakerFeeDiscount`.
- Package version bumps from `0.5.34` to `0.5.35`.

### Breaking Changes

- `BuilderState` gains four required fields. Code that constructs `BuilderState` objects by hand (for example mocks or fixtures) will no longer type-check until the fields are added. Code that only reads parsed accounts is unaffected.
- The `BuilderState` decoder now reads the onboarding fields at the offsets that follow `feeBps`. It expects the current on-chain layout, and the reserved padding after the new fields is smaller than before. Parsing builder state accounts from an older program layout may give wrong values.

### Consumer Notes

- `buildOnboardTraderIx` requires `builderAuthority`, `onboarderSigner`, `payer`, `traderWallet`, `riskAuthority`, `marketAuthority`, `maxPositions`, `traderPreferenceBits`, `globalTraderIndex` and `activeTraderBuffer`.
  - `maxPositions` and `traderPreferenceBits` must be integers in `0..2^32-1`.
  - Both arrays must be non-empty.
  - `logAuthorityAddress` and `globalConfigurationAddress` are optional overrides.
- `buildOnboardTraderIx` derives the trader account as the wallet's PDA index 0 / subaccount 0 and the two permission accounts from `riskAuthority` and `marketAuthority`. The `onboarderSigner` and `payer` must both sign the transaction.
- `buildSetOnboarderSignerIx` takes `builderAuthority` and the new `signer` address. The builder authority must sign.
- Both builders are exported through the `flight` namespace.

## v0.5.34 - 2026-09-28

Source Phoenix commit: `65e3246ec6c43bc24dc33cbfba075dfd8d561134`

### Summary

- Adds `V1TradersClient.getTwap(authority, params?)`, which calls `GET /v1/trader/{authority}/twap` and returns a validated `TwapSnapshot`. The optional filters are `traderPdaIndex` (defaults to 0 on the server), `traderSubaccountIndex` and `assetId`.
- Adds new public exports for the TWAP read API: `TwapSnapshot`, `TwapAccountSnapshot`, `TwapOrderSnapshot`, `TwapOrdersQueryParams`, and the matching Zod schemas `TwapSnapshotSchema`, `TwapAccountSnapshotSchema` and `TwapOrderSnapshotSchema`. They are available from the package root and the API schema exports.
- TWAP order snapshots now report dust execution parameters. `nDustOrders` is the number of additional dust executions, and `dustOrderSize` is the size of each one in base lots (or `null`). `nChildOrders` counts all executions, dust included.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `nDustOrders` and `dustOrderSize` are optional, so snapshots from older servers that omit them still parse. Treat a missing or `0` `nDustOrders` as "no additional dust executions". `0` can also mean dust from the legacy final child order.
- Accounts with no active TWAP order have no `order` field.
- Sizes and cumulative fills are in lots. Numeric fields are typed as `number`, not string or bigint.

## v0.5.33 - 2026-09-25

Source Phoenix commit: `753ef9222464d261902edd20ddd988a5d763821f`

### Summary

- Added a new `PnlValuesRequest` type for `getTraderPnl` and `getTraderPnlValues`, making `resolution` optional. When omitted, the server clamps the window to the account's creation time and picks the finest resolution that fits `limit` points.
- Exported `PnlValuesRequest` from the public API schemas entry point.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `getTraderPnl` and `getTraderPnlValues` now accept `PnlValuesRequest` instead of `HistoricalValuesRequest`; existing calls that pass `resolution` continue to work unchanged.
- You can now omit `resolution` when requesting trader PnL history and let the server pick an appropriate resolution automatically.

## v0.5.32 - 2026-09-25

Source Phoenix commit: `a7a82ea1228fb52ad23501993b513a1226516de3`

### Summary

- Added `getUserCollateralTotals`, returning lifetime per-asset deposit/withdrawal totals (`CollateralTotalsResponse`, `CollateralAssetTotals`, `CollateralFlowTotal`).
- Added mixed-asset collateral history v2 endpoints (`getUserCollateralHistoryV2`, `getTraderCollateralHistoryV2`, `getTraderPdaCollateralHistoryV2`) covering both quote and spot collateral assets, with new `CollateralEventV2` / `CollateralHistoryV2Request` / `CollateralHistoryV2Response` types.
- Added TWAP order request types and schemas (`PlaceTwapOrderRequest`, `TwapChildOrderParams`, `IsolatedTwapOrderParams`), supporting configurable dust-order sizing and isolated-margin collateral transfers.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- The v2 collateral history endpoints require an explicit `limit` param, unlike the optional `limit` on v1 history calls.
- Native-unit quantities (`amount`, `balanceAfter`, `excess`, and totals `amount`) are now validated as safe integers; values beyond `2^53 - 1` throw instead of being silently rounded.
- `nDustOrders` on `PlaceTwapOrderRequest` is opt-in: omitted or `0` preserves prior sizing behavior, while a positive count requires `childOrderParams.dustOrderSize > 0`.

## v0.5.31 - 2026-09-25

Source Phoenix commit: `a698c95f16a657ce6a8a2e1f5a4bec469e9cc273`

### Summary

- TWAP dust handling now supports an explicit `nDustOrders` count alongside `dustOrderSize`, instead of only a single final-child dust order, and is encoded/decoded on the `PlaceTwapOrder` instruction and `TwapIocOrderPacketData`.
- `MarginMarketParamsStore.updateMarkPrices` now merges partial price updates onto previously known prices instead of requiring a full price map every call, and mark/index price lookups match symbols case-insensitively (rejecting ambiguous aliases).
- Fixed the market data client so `close()` reliably stops in-flight streams and stale retry loops are not revived after `reconnect()`.
- Fixed orderbook and trader-state resource subscriptions so they restart correctly after being released and re-retained.

### Breaking Changes

- `TwapIocOrderPacketData` gains a required `nDustOrders: bigint` field; code that constructs this object directly (rather than via `encodeTwapIocOrderPacket`/the decoders) must add it. The packet's reserved tail shrank from 40 to 32 bytes to make room for it.
- TWAP dust validation changed: the old "at least 2 child orders" requirement is gone, replaced by `nDustOrders` needing to be between 0 and `nChildOrders`; a nonzero `dustOrderSize` must now always be strictly less than the child order size, and `nDustOrders > 0` requires a nonzero `dustOrderSize`.
- `MarginMarketParamsStore.updateMarkPrices` no longer fully replaces the store's known mark prices on each call — it merges the given partial update with previously known prices. Consumers relying on omitted symbols being treated as missing (per `missingPriceBehavior`) on every call will now see the last known price retained instead.

### Consumer Notes

- `getPlaceTwapOrderDecoder()` and `decodeTwapIocOrderPacket()` output now both include the new `nDustOrders` field.
- Existing TWAP calls that only set `dustOrderSize` (no `nDustOrders`) keep the legacy single-final-child-dust behavior and still encode byte-for-byte identically when dust is disabled.
- Mark/index price lookups now fall back to a case-insensitive, whitespace-trimmed symbol match when no exact key exists, and throw if that fallback is ambiguous across multiple keys in the provided price map.

## v0.5.30 - 2026-09-25

Source Phoenix commit: `4c5553d3365a7f72273dfe4a67fe7240f3f42951`

### Summary

- `getPerpAssetMapMetadataEntriesDecoder` / `getPerpAssetMetadataDecoder` now tag-filter perp asset map slots, excluding spot collateral collection entries that previously could be intermixed with perp market metadata.
- Removed the SDK-side 64-order cap (`MAX_SCALE_ORDERS`) from scale-order helpers — `clampScaleOrderCount`, `previewScaleOrder`, `scaleLevelsToMultipleOrderPacket`/`V2`, `chunkScaleLevelsForTx`, and `buildPlaceMultiLimitOrderFlow` no longer clamp, warn, or throw at 64 orders per side.
- Instruction fixtures dropped two retired Phoenix instructions (`SetMultiArenaAdditionalNodesWatermark`, `SetMultiArenaNumNodesPerArena`).

### Breaking Changes

- `MAX_SCALE_ORDERS` is no longer exported from `@ellipsis-labs/rise`. Consumers importing it must supply their own limit.
- `ScaleOrderWarningCode` no longer includes the `"ORDER_COUNT_EXCEEDS_MAX"` variant; `previewScaleOrder` no longer emits that warning.
- `clampScaleOrderCount`, `scaleLevelsToMultipleOrderPacket`, `scaleLevelsToMultipleOrderPacketV2`, and `buildPlaceMultiLimitOrderFlow` no longer reject or clamp ladders above 64 orders per side — any code relying on that guard for validation must add its own check.
- `chunkScaleLevelsForTx` no longer caps `maxOrdersPerTx` at 64, so a large explicit value now yields larger chunks than before.

### Consumer Notes

- If you relied on the SDK enforcing the 64-order-per-side on-chain limit, add an explicit check before calling the scale-order builders or the multi-limit-order flow.
- Decoded `PerpAssetMap` results now contain perp market entries only; drop any existing workaround that filtered out spot collateral entries yourself.

## v0.5.29 - 2026-09-25

Source Phoenix commit: `fb668c205addd8ab46faf23f335c4e092d2340c1`

### Summary

- Market symbol handling switched from forcing `UPPERCASE` everywhere to case-insensitive lookups that preserve the exchange's canonical symbol casing (e.g. `kBONK` instead of `KBONK`). This touches the exchange cache, market-data, orderbook, and trader-state managers/selectors, as well as all WebSocket adapter/plugin subscription routing.
- `GlobalConfiguration` gains a new decoded field, `pendingWithdrawThrottleReplenishment: QuoteLots`, carved out of previously reserved padding.
- Version bump to `0.5.29`.

### Breaking Changes

- WebSocket subscription/routing keys are now lowercase-normalized instead of uppercase (e.g. `l2Book:SOL-PERP` → `l2Book:sol-perp`, `orderbook:SOL-PERP:bypassExecutionBand` → `orderbook:sol-perp:bypassExecutionBand`, `marketStatsV2:["SOL-PERP"]` → `marketStatsV2:["sol-perp"]`). Any code matching against these exact key strings must update to lowercase.
- Symbols returned from `market()`, `.symbol` getters, orderbook/market-data resources, and selectors now reflect the exchange's canonical casing rather than being forced to uppercase — code that assumed all returned symbols were uppercase (e.g. strict `===` comparisons) can break even though lookups themselves remain case-insensitive.
- `GlobalConfiguration` decoding now produces a new required field `pendingWithdrawThrottleReplenishment: QuoteLots`, taken from what was previously reserved padding (`_padding1` shrank from 22 to 21 `u64` slots). Code that constructs `GlobalConfiguration` objects by hand (rather than decoding) needs to supply this field.

### Consumer Notes

- Symbol-keyed lookups (`market(symbol)`, `position(subaccount, symbol)`, `orders(...)`, `triggers(...)`, etc.) continue to accept any casing, so most call sites are unaffected — only code that inspects or compares the returned `symbol` string, or that hardcodes WS routing keys, needs review.
- If you cache or persist symbols keyed by the old uppercase convention, re-derive keys from the SDK's returned `symbol` values going forward.

## v0.5.28 - 2026-09-22

Source Phoenix commit: `b1a3b8f6bfce1a9e6fb77465d77dc82b3879e065`

### Summary

- Marked the legacy stop-loss API surface as `@deprecated` in favor of the newer conditional-order APIs, with no change to runtime behavior.
- Deprecated items span the `V1OrdersClient` (`placeStopLossOrder`, `cancelStopLossOrder`), request/config types (`TpSlOrderConfig`, `PlaceStopLossOrderRequest`, `CancelStopLossOrderRequest`, the `tpSl` field on isolated limit/market order requests), instruction builders (`buildPlaceStopLoss`, `buildCancelStopLoss`, `buildPlaceStopLossIx`, `buildCancelStopLossIx`, their resolved variants), and the `PhoenixIxClient` interface methods `buildCancelStopLoss` / `buildPlaceStopLoss`.
- Each deprecation notice points to its conditional-order replacement (e.g. `placePositionConditionalOrder`, `cancelConditionalOrder`, `greaterTrigger`/`lessTrigger`).
- Package version bumped to `0.5.28`.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- No runtime or type-shape changes — this release only adds `@deprecated` JSDoc annotations, which may surface new editor/IDE warnings or lint errors (e.g. `no-deprecated`) if you use the legacy stop-loss APIs.
- Plan a migration to the conditional-order APIs referenced in each deprecation notice, as the legacy stop-loss surface is expected to be removed in a future release.

## v0.5.27 - 2026-09-22

Source Phoenix commit: `43aba601e5ce668b168aff936d48a55aafa81985`

### Summary

- Spot collateral valuation now requires an index price whenever the collateral balance is nonzero, and no longer falls back to the pricing market's mark price.
- Zero-balance spot collateral entries are now valued as zero directly, without requiring matching market params or an index price.
- Liquidation price calculations skip zero-balance spot collateral entries entirely.

### Breaking Changes

- `valueSpotCollateral` (via `computeSubaccountMarginFromInputs`) now throws `Missing index price for spot collateral <symbol>` when a nonzero-balance spot collateral has no `indexPriceTicks` and no matching market's `indexPriceTicks`. Previously this silently fell back to the market's mark price. Consumers passing spot collateral without `indexPriceTicks` must now supply one whenever the balance can be nonzero.
- `SpotCollateralMarginInput.indexPriceTicks` no longer defaults to the pricing market's mark price; its doc comment now states a nonzero balance without an index price fails valuation.

### Consumer Notes

- If you rely on mark-price fallback for spot collateral valuation, switch to explicitly passing `indexPriceTicks` (or ensure the market params include `indexPriceTicks`) before upgrading.
- Zero-balance spot collateral entries can now be passed without `indexPriceTicks` or matching market params — useful for representing "no position" placeholders without extra guarding logic.

## v0.5.26 - 2026-09-18

Source Phoenix commit: `0068e7b92afaceb98ab8a55f88f2909f1bcfabdf`

### Summary

- Added an optional `classifications` field (nullable string array) to `MarketPublicMetadata`, exposed via `MarketPublicMetadataSchema` and reflected in exchange snapshot/delta comparisons in the exchange cache store.
- Added an optional `parentTwapId` field to trader-state WebSocket trade history deltas (`TraderStateTradeHistoryDelta`) and to `TradeHistoryV2Item`, backed by a new shared `ParentTwapIdSchema` export (`ts/src/api/utils/parentTwapId.ts`).

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `classifications` is optional/nullable and omitted values remain backward compatible; no consumer changes required unless you want to read the new field (e.g. `"pre-ipo"`, `"new-listing"`).
- `parentTwapId` is optional/nullable on trade history records, but if present it must be a non-empty string — empty-string values will now fail schema validation.

## v0.5.25 - 2026-09-15

Source Phoenix commit: `cdd5303fea774b0609f2402dee4e387dbf90714a`

### Summary

- `buildNativeSolDepositFlow` (wallet-paid) now prepends a `ReallocTrader` instruction to reserve trader account map capacity before the SOL transfer and `SyncNative`, exposed as `flow.named.reallocTrader`; already-sufficient capacity is a no-op.
- Sponsored native SOL deposits must now confirm that wallet-paid capacity preparation already ran, via a new required `traderCapacityPrepared: true` flag; the sponsored transaction itself still contains only the transfer + sync.
- `test-fixtures/default-localnet.json` (and its `ts/test-fixtures` mirror) adds a `sol-collateral-setup` action template for configuring SOL collateral with a fixed margin discount in local test setups.

### Breaking Changes

- `NativeSolDepositFlowParams` (sponsored variant) now requires `traderCapacityPrepared: true`. Calls that omit it throw `"Sponsored native SOL deposits require traderCapacityPrepared: true after wallet-paid ReallocTrader preparation"`.
- Non-sponsored `buildNativeSolDepositFlow` output can now include an additional leading `reallocTrader` instruction in `flow.instructions`; code that assumed exactly two instructions (`transferSol`, `syncNative`) must account for this new optional leading entry.

### Consumer Notes

- Existing sponsored-flow integrations that already perform a wallet-paid `ReallocTrader` step before sponsorship just need to add `traderCapacityPrepared: true` to the call — no other change required.
- `flow.named.reallocTrader` is `undefined` for sponsored flows and populated for wallet-paid flows; check for its presence before consuming `flow.named` or `flow.instructions` positionally.

## v0.5.23 - 2026-09-15

Source Phoenix commit: `9a60c7ba487c57c88a8769607120204ffc3bc3de`

### Summary

- Added a new `buildReallocTraderIx` instruction builder (with `ReallocTraderParams`) for reserving additional space on a trader account ahead of collateral/extension writes, exported from the package's public instruction builders.
- `OracleParameters` now decodes `bookHardStaleMultiplier` and `oracleHardStaleMultiplier` out of bytes that were previously unread padding.
- `PerpAssetMetadata` now exposes a `finalizedMarkPrice` field, also decoded from previously unread padding.
- Package version bumped to `0.5.23`.

### Breaking Changes

- `OracleParameters` and `PerpAssetMetadata` each gained new required fields (`bookHardStaleMultiplier` / `oracleHardStaleMultiplier`, and `finalizedMarkPrice`). Any downstream code constructing object literals typed as these interfaces (e.g. mocks or test fixtures) will fail to compile until updated; decoded values read from real accounts are unaffected since the new fields only consume bytes that were previously reserved padding.

### Consumer Notes

- No account byte layout or existing instruction account ordering changed — the new fields simply read bytes that were already reserved as padding.
- The supported instruction set grows from 118 to 119 entries with the addition of `ReallocTrader`; no existing instruction discriminants or account lists changed.

## v0.5.22 - 2026-09-15

Source Phoenix commit: `e902efb7e98b284b8a56cae5c98df492a7d0ac4b`

### Summary

- Adds an `ExchangeRunningState` ("unknown" | "active" | "maintenance" | "suspended") surfaced via a new `getExchangeRunningState` helper, `ExchangeStatusView.runningState`, `ExchangeStateSnapshot.runningState`, and new `runningState`/`previousRunningState` fields on the `exchange` and `exchange-status` WebSocket payloads.
- Reserves bit 7 of the wire `scale_set_id` byte for a "continuation" flag, shrinking the valid caller-assigned ladder id range from `1..=255` to `1..=127`; adds `encodeScaleSetTag`/`decodeScaleSetTag` helpers and `MAX_SCALE_SET_ID`/`SCALE_SET_CONTINUATION_BIT` constants.
- Adds `scaleSetContinuation` to `buildPlaceMultiLimitOrderFlow`, letting a tagged scale ladder span multiple transactions (previously rejected outright); batches now report `index`, `total`, and `scaleSetContinuation`.
- Adds `decodeLastRestartSlot`/`fetchLastRestartSlot` account helpers, and optional `circulatingSupply` / `circulating_supply` / `market_cap` fields on market metadata and stats responses.

### Breaking Changes

- `scaleSetId` inputs to `buildPlaceMultiLimitOrderFlow`, `scaleLevelsToMultipleOrderPacketV2`, and the `PlaceMultiLimitOrderV2` instruction builder now must be `0..=127` (was `0..=255`); ids `128-255` now throw. `cancelIdsForScaleSet` still accepts `1..=255` so existing legacy-tagged resting orders remain cancelable.
- `DEFAULT_MAX_ORDERS_PER_TX` and `DEFAULT_MAX_ORDERS_PER_TX_V2` are no longer exported from the package root (`@ellipsis-labs/rise`); they remain internal to `scaleOrders`.
- `isExchangeEffectivelyActive` / `getExchangeRunningState` behavior changed: when `acknowledgedRestartSlot` is `0n`, the exchange is now only reported active if `lastRestartSlot` is also `0n`. Previously any `lastRestartSlot` (including `null`) was treated as active in that case.
- `ExchangeStatusPayload.authority` (WS `exchange-status` wire type) is now optional (`string | undefined`) instead of a required `string`.

### Consumer Notes

- Prefer `runningState`/`getExchangeRunningState` over the `active`/`gated` booleans when you need to distinguish "maintenance" from "suspended" exchange states.
- Ladders that must span transactions require both `scaleSetContinuation: true` on the flow call and an upgraded on-chain program; batches must be submitted in order and each confirmed (not just accepted) before sending the next — see the updated `scaleSetContinuation` field docs in `flows.ts` for the failure/rollback contract.
- Use `encodeScaleSetTag`/`decodeScaleSetTag` rather than hand-rolling the `scale_set_id` byte if you need to set or inspect the continuation bit directly.

## v0.5.21 - 2026-09-15

Source Phoenix commit: `bddefbeebaa0c477268fbbc791888053219da2e6`

### Summary

- Added atomic isolated market order protection (v2): `placeIsolatedMarketOrder()` and `placeIsolatedMarketOrderEnhanced()` now accept `greaterTrigger`, `lessTrigger`, and `sizePercent: 100` for full-position TP/SL that shares one conditional and cancels together when either side executes. Requires a backend release containing PRO-829.
- Added `withdrawableQuoteCollateral` to `TraderView` and `withdrawableQuoteCollateralQuoteLots` to `MarginTotals`, mirroring the on-chain `get_max_quote_withdrawable_amount`: the tighter of (effective withdrawal collateral + discounted spot collateral − initial margin for withdrawals) and the positive part of effective withdrawal collateral.
- Clarified doc comments around spot collateral and withdrawal margin semantics; no behavior change to existing `effectiveCollateralForWithdrawals*` fields.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- v2 protection fields are optional and additive; requests must supply at least one trigger with `sizePercent: 100` and cannot combine them with legacy `tpSl` — the request schema now enforces this via a `.refine()` check, so previously-passing requests that happened to mix these fields will now fail validation.
- `withdrawableQuoteCollateral` defaults to a zero `TokenAmount` when parsing responses from older API versions that predate the field, so no manual migration is needed for existing integrations.
- Partial and fixed-lot protection are not supported on the new isolated market-order v2 path; use `side: "buy"` on closing triggers for short entries (take profit becomes the less trigger, stop loss the greater trigger).

## v0.5.20 - 2026-09-15

Source Phoenix commit: `8b62fb6aea0f7e8520ebee0bf72698295264a23a`

### Summary

- Bumped the minimum supported Bun version from `1.3.13` to `1.4.2` (`packageManager` and `engines.bun` in `package.json`).
- Updated the `vitest` devDependency from `^4.1.8` to `^4.1.11`; no other dependency or lockfile changes affect published output.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- If you install or run `@ellipsis-labs/rise` with Bun, upgrade to Bun `>=1.4.2` to match the package's declared `engines` requirement.
- The `vitest` bump is a devDependency-only change (test tooling) and does not affect the package's runtime behavior or public API.

## v0.5.19 - 2026-09-15

Source Phoenix commit: `d20f17df1c201ce9eb1b31c3927d5bb73b51cb98`

### Summary

- Added a `cumulativeMakerFee` field to `PnlDataPoint`, returned by `getTraderPnl` and `getTraderPnlValues`, alongside the existing `cumulativeTakerFee` fee breakdown.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `cumulativeMakerFee` is required (non-optional `number`) in the `PnlDataPointSchema` Zod validator, so any local mocks or fixtures for `PnlDataPoint` responses should include this field to keep parsing/tests passing.

## v0.5.18 - 2026-09-15

Source Phoenix commit: `7fc763a0ec5ef143b123c0990ec836847056aba5`

### Summary

- Added a new `marketStatsV2` WebSocket channel/adapter (`createMarketStatsV2Adapter`, `ws.marketStatsV2`) supporting multi-symbol batch subscriptions (all markets, one symbol, or an explicit symbol list) and an optional `midPrice` field on stats.
- New exported types/schemas for the V2 channel: `MarketStatsV2Adapter`, `MarketStatsV2AdapterOptions`, `MarketStatsV2Port`, `MarketStatsV2Selector`, `MarketStatsV2Data`, `MarketStatsV2Msg`, `MarketStatsV2Update`, `MarketStatsV2WireData`, `MarketStatsV2MsgSchema`, `MarketStatsV2UpdateSchema`, `MarketStatsV2WireDataSchema`.
- `PhoenixWsClient` gains a `marketStatsV2` field, and `PublicAdapterOptions` gains a `marketStatsV2` option, alongside the existing `marketStats`.
- The existing `createMarketStatsAdapter` / `ws.marketStats` stream is now implemented on top of the `marketStatsV2` channel internally; its public signature and emitted `MarketStatsUpdate` shape are unchanged.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `marketStats()` now subscribes on the wire using the `marketStatsV2` channel instead of `marketStats`; this is transparent through the SDK's public API but means the backing server must support `marketStatsV2` for the existing `marketStats` stream to keep working.
- Prefer the new `marketStatsV2` adapter/channel going forward if you need multi-symbol batching or the `midPrice` field — it delivers stats as grouped batches (`{ symbols?, stats[] }`) rather than one update per symbol.

## v0.5.17 - 2026-09-15

Source Phoenix commit: `5e0a1182c2f04b0cc37ab635e7bef509d40cc1f4`

### Summary

- TWAP orders support an optional final "dust" child order size (`dustOrderSize`) so the last child can trade a smaller remainder instead of an equal-sized slice; encoded at a newly carved-out offset in the previously reserved IOC packet tail.
- Added `buildEnableTwapIxs` / `buildDisableTwapIx` plus `getTwapDelegatePermissionAddress` and `POSITION_AUTHORITY_PERMISSION` to enroll/revoke a trader's TWAP execution permission against the shared Flicker delegate.
- Take-profit/stop-loss (`TpSlOrderConfig`) price fields and stop-loss `executionPrice` now reject zero/non-positive values at validation time.
- Bumped the `@humanfs/node` override to `>=0.16.8` (transitive dependency, no API impact).

### Breaking Changes

- `TpSlOrderConfigObjectSchema` now uses `.positive()` instead of `.nonnegative()`/no-bound for all trigger and execution price fields (`takeProfitTriggerPrice(InTicks)`, `takeProfitExecutionPrice(InTicks)`, `stopLossTriggerPrice(InTicks)`, `stopLossExecutionPrice(InTicks)`). Values of `0` that previously validated will now throw.
- `buildPlaceStopLossIx` (`PlaceStopLoss/ix.ts`) now throws `"Execution price must be greater than 0 ticks"` if `executionPrice <= 0n`, whereas `0n` was previously accepted.
- `TwapIocOrderPacketData` gained a required `dustOrderSize: BaseLots` field. Code that builds this object as a literal (rather than via `decodeTwapIocOrderPacket`) will fail to type-check until `dustOrderSize` is supplied.

### Consumer Notes

- `encodeTwapIocOrderPacket(packet, dustOrderSize?)` defaults `dustOrderSize` to `0n`, so existing single-argument calls keep producing byte-identical output.
- `PlaceTwapOrderParams.dustOrderSize` is optional; when set it requires `nChildOrders >= 2` and must be strictly less than the child order's `numBaseLots`, or the builder throws.
- To enroll a trader for TWAP, derive the permission PDA with `getTwapDelegatePermissionAddress`, then submit `buildEnableTwapIxs(...).instructions` (CreatePermission + SetPermission granting `POSITION_AUTHORITY_PERMISSION`); use `buildDisableTwapIx` to revoke via a zero-permission `SetPermission`.

## v0.5.16 - 2026-09-15

Source Phoenix commit: `a4bf845528348e8f3966a50c066057820100a84b`

### Summary

- Adds native SOL deposits: `buildTransferSolIx`, `buildNativeSolDepositFlow`, and spot-collateral-cap helpers (`nativeSolCollateralHeadroomLamports`, `attributedNativeSolDepositLamports`, `nativeSolSyncDeltaLamports`, `nativeSolUnaccountedLamports`) for sizing deposits against per-trader/exchange caps.
- Adds `client.rpc.accounts.getLamportAccountState()` (and exported `LamportAccountState` type) to read an account's raw lamport balance and rent-exempt minimum, used by the native SOL deposit helpers.
- Adds an optional shared, client-local rate-limit cooldown (`rateLimitCooldown` client config) that makes later idempotent GET/HEAD requests wait out a `429 Retry-After` window from a prior response; enabled by default, capped at 30s, and disableable via `rateLimitCooldown: false`.
- `timeout` is now documented and enforced as a per-attempt network timeout rather than a budget shared across internal retries.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `timeout` behavior changed: each network attempt (including automatic rate-limit retries) now gets its own full timeout window instead of sharing one budget across the whole request. Long-running retry sequences can now take longer in aggregate than before.
- The new `rateLimitCooldown` default is opt-out, not opt-in — long-lived clients hitting `429`s will now see subsequent GET/HEAD requests delayed automatically. Pass `rateLimitCooldown: false` to restore prior behavior.
- `buildNativeSolDepositFlow` only builds the transfer + `SyncNative` instructions; callers must still compose `buildRegisterTrader` first if the trader account doesn't exist, and should size deposits with `nativeSolCollateralHeadroomLamports` since `SyncNative` silently clamps (not rejects) credit above the per-trader/global caps.

## v0.5.15 - 2026-09-15

Source Phoenix commit: `441ecc64f8549695ebe49cd2cf464550a0c60965`

### Summary

- Added `getCandlesV2` to the candles client (`ApiCandleV2`, `CandlesV2Response`, `CandlesV2Page`, and related query types), supporting cursor-based pagination, mark-price OHLC, `isFinal`, and external-source metadata; the existing `getCandles` method and its legacy 2,500-bar endpoint are unchanged.
- Added an `isExchangeEffectivelyActive` helper and a new `acknowledgedRestartSlot` field on `GlobalConfiguration` so exchange-cache "active" status can be reconciled against the on-chain `LastRestartSlot` sysvar after a validator/network restart.
- `MarketPublicMetadata` gains an optional `searchAliases: string[]` field, propagated through the exchange WebSocket adapter and cache store/selectors.

### Breaking Changes

- Exchange-cache "active" status can now resolve to `false` immediately after a restart (until the restart slot is acknowledged on-chain), even when `GlobalConfiguration.exchangeStatus` bits still read active — code that inspects the raw status bits directly should switch to `isExchangeEffectivelyActive`.
- RPC bootstrap for exchange metadata now fetches an additional sysvar account (`SYSVAR_LAST_RESTART_SLOT_ADDRESS`) alongside `GlobalConfiguration` and `PerpAssetMap`; code asserting on the count/order of accounts in that `getMultipleAccounts` call will need updating.

### Consumer Notes

- New runtime dependency: `@solana/sysvars` (`^4.0.0`), required by the exchange-cache RPC bootstrap path.
- `GlobalConfiguration` decoding adds `acknowledgedRestartSlot: bigint` (carved out of previously reserved padding); total account size is unchanged, so existing raw-byte parsing outside the SDK decoder is unaffected.
- Prefer `getCandlesV2` for new integrations needing pagination or mark-price data; it defaults to 1,000 bars per page (server max 10,000) vs. the legacy endpoint's 2,500-bar cap.

## v0.5.14 - 2026-09-14

Source Phoenix commit: `be93e77bc13e301ace3c9cd7132e867d258ce17e`

### Summary

- Added a new `spot_collateral_liquidation` WebSocket event notification type, including `SpotCollateralLiquidatedEventData`/`SpotCollateralLiquidationDetails` types and their Zod schemas, exposed via `EventNotificationItem` and `NotificationItemSchema`.
- Removed two Phoenix program instructions (`SetExchangeStatusBits`, `DisableExchangeCapabilities`) from the generated instruction fixture set, reducing the tracked instruction count from 118 to 116.

### Breaking Changes

- The `SetExchangeStatusBits` and `DisableExchangeCapabilities` instructions are no longer part of the generated instruction set. Any consumer code building or decoding these instructions against the Phoenix program should remove that usage, as the on-chain instructions they targeted are no longer present.

### Consumer Notes

- New `spot_collateral_liquidation` notifications are additive: `EVENT_NOTIFICATION_TYPES`, `EventNotificationItem`, and `NotificationItemSchema` now include this variant, so exhaustive `switch`/discriminated-union handling over notification types should add a case for it.
- `SpotCollateralLiquidatedEventData` mirrors the shape of existing liquidation event data (bigint-like numeric fields, string pubkeys for `liquidator`/`liquidatedTrader`), so existing bigint/pubkey parsing helpers can be reused.

## v0.5.13 - 2026-09-14

Source Phoenix commit: `a5e6fdf08f31c275a2d366f136834a6d29501833`

### Summary

- Added forward-compatible handling for event notifications: unknown/future `notificationType` values now parse as a new `UnknownEventNotification` (with `rawNotificationType` preserving the original wire value) instead of failing to parse.
- Added `cancelIdsForScaleSet` (with a new `ScaleSetCancelableOrderRow` row type) to convert a market's scale-set order rows into `CancelId`s for `buildCancelOrdersByIdIxResolved`.
- Bumped package version to `0.5.13`.

### Breaking Changes

- `EventNotificationItem` gained a new `UnknownEventNotification` member; code that exhaustively switches on `notificationType` (e.g. a `never`-typed default case) will need to add an `"unknown"` branch to keep compiling.
- `examples/10-builder-onboarding-tx.ts` replaced `--trader-keypair-path` / `TRADER_KEYPAIR_PATH` / `KEYPAIR_PATH` with `--fee-payer-keypair-path` / `FEE_PAYER_KEYPAIR_PATH` (default `~/.config/solana/id.json`) plus an optional `--trader-authority` / `TRADER_AUTHORITY` public key; the fee payer is now the only local signer, so existing invocations passing a trader keypair path must switch to these new flags.

### Consumer Notes

- `cancelIdsForScaleSet` throws if `scaleSetId` is outside `1..=255`, or if a row's `priceTicks`/`orderSequenceNumber` isn't a canonical non-negative decimal string within u64 range; a two-sided scale set can return up to 128 ids, above the 100-id cap for `buildCancelOrdersByIdIxResolved`, so callers must chunk larger results themselves.
- README docs (`README.md`, `ts/README.md`, `ts/examples/README.md`) were updated to describe the builder-onboarding example's new signer model and default keypair path.

## v0.5.12 - 2026-09-14

Source Phoenix commit: `444e5fcc741719021c13a92e16e573f385357c60`

### Summary

- Added a V2 multi-limit order instruction builder (`buildPlaceMultiLimitOrderV2Ix`, `PlaceMultiLimitOrderV2Params`) with matching codecs (`getPlaceMultiLimitOrderV2Codec/Decoder/Encoder`) for placing scale/ladder order batches.
- Added new order-packet primitives supporting V2 orders: `CondensedOrderFlags`, `CondensedOrderV2`, `MultipleOrderPacketV2`, and their encoder/decoder pairs.
- `OrderHistoryItem`, `PlacedOrder`, `CurrentOrderState`, `TraderStateMarketLimitOrderRow`, and `LimitOrder` now expose an optional `scaleSetId` (1-255) that groups legs placed together via a `PlaceMultiLimitOrderV2` scale-order batch.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- Import the new V2 builder and primitives from the package's public export paths (e.g. `@/ixs/operations`, `@/primitives`) rather than internal module paths — internal-path imports for these symbols are no longer guaranteed stable.
- `scaleSetId` is optional and only populated for orders placed as part of a V2 scale-order batch; existing standalone-order handling needs no changes.
- The ladder-math helper `scaleLevelsToMultipleOrderPacketV2` remains internal (not exported); use `buildPlaceMultiLimitOrderV2Ix` for scale-order placement.

## v0.5.11 - 2026-09-14

Source Phoenix commit: `41d501ac9b4b1f84fe680987d4e491cac0d55338`

### Summary

- Added a `place_multi_limit_order_v2` instruction path: new `buildPlaceMultiLimitOrderV2Ix`, `getPlaceMultiLimitOrderV2Codec`/`Encoder`/`Decoder`, `PlaceMultiLimitOrderV2Params`, `MultipleOrderPacketV2`, `CondensedOrderV2`, and `CondensedOrderFlags` (`Slide`, `ReduceOnly`) exports.
- `buildPlaceMultiLimitOrderFlow` gains `scaleSetId` and `reduceOnly` params. Setting either now automatically routes the batch through the V2 instruction instead of the legacy one.
- Added `DEFAULT_MAX_ORDERS_PER_TX_V2` (24) — the smaller per-transaction default used for V2 batches, since each V2 leg is wider on the wire than a legacy no-expiry leg.
- `chunkScaleLevelsForTx` accepts a new `usesV2Instruction` option to pick the right default chunk size.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- V2 dispatch is automatic and based on params, not a separate flow function: pass `scaleSetId` (`1..=255`) and/or `reduceOnly: true` to `buildPlaceMultiLimitOrderFlow` to opt into `place_multi_limit_order_v2`; omitting both keeps the legacy `place_multi_limit_order` path and discriminant unchanged.
- A non-zero `scaleSetId` tags every resting leg with a caller-assigned ladder id (must be unique among the trader's resting orders on the market); the flow throws if the ladder needs more than one transaction, since a `scaleSetId` can't span transactions.
- In `CondensedOrderV2`, `lastValidSlot` is now a raw `u64` with `0` reserved as the "no expiry" sentinel (encoders/decoders reject an explicit `0n`) rather than a borsh `Option`, and per-order `slide`/`reduceOnly` now live in a `flags` byte instead of packet-wide fields — relevant if you build `MultipleOrderPacketV2` values directly instead of via `scaleLevelsToMultipleOrderPacketV2`.
- If you call `chunkScaleLevelsForTx` directly for a V2 batch, pass `usesV2Instruction: true` (or your own `maxOrdersPerTx`) to get correctly sized chunks.

## v0.5.10 - 2026-09-14

Source Phoenix commit: `29c2f9e5571ff898b32cf6a2e3a310bde2016ae9`

### Summary

- Bumped `@ellipsis-labs/rise` to `0.5.10`.
- Updated the `nanoid` dependency from `^3.3.17` to `^3.3.18` (patch-level bump, lockfile updated accordingly).

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- No action required; this is a routine dependency patch update with no changes to public exports, types, or runtime behavior.

## v0.5.9 - 2026-09-14

Source Phoenix commit: `cd96962f181a2e28c87ec592db4f20460c6b510e`

### Summary

- Added TWAP (time-weighted average price) order support: new instruction builders `buildCreateTwapAccountIx`, `buildPlaceTwapOrderIx`, `buildExecuteTwapOrderIx`, `buildCancelTwapOrderIx`, and `buildCloseInactiveTwapAccountIx`, plus matching encoders/decoders and PDA helpers (`getTwapGlobalStateAddress`, `getTwapLogAuthorityAddress`, `getTwapAccountAddress`).
- Added `FLICKER_PROGRAM_ADDRESS` and `FLICKER_DISCRIMINANTS` exports for the new Flicker (TWAP) program, plus new branded address types `TwapGlobalStateAddress`, `TwapAccountAddress`, `TwapLogAuthorityAddress`, and `FlickerProgramAddress`.
- Added `TWAP_IOC_ORDER_PACKET_BYTE_LENGTH` / `TWAP_IOC_ORDER_PACKET_DISCRIMINANT` constants and `encodeTwapIocOrderPacket` / `decodeTwapIocOrderPacket` helpers for building TWAP child-order IOC packets.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- All TWAP builders require `twapGlobalStateAddress` and `twapLogAuthorityAddress`, resolvable via the new PDA helpers; `flickerProgramAddress` and `hawkeyeProgramAddress` are optional overrides that default to the published program addresses.
- `buildPlaceTwapOrderIx` / `buildExecuteTwapOrderIx` take a `transferAccounts` + `orderAccounts` CPI account tail (`TwapChildOrderCpiTail`); optional numeric fields (e.g. `childOrderMinPriceInTicks`, `priceInTicks`) reject an explicit `0` — pass `null`/omit instead.
- This release is additive only for existing consumers; no previously published exports, instruction formats, or PDA derivations changed.

## v0.5.8 - 2026-09-14

Source Phoenix commit: `cca7cbac0ce315d181325cda81d711386d98b7a9`

### Summary

- Added support for a new `stop_loss_order_placed` event notification, emitted when a stop-loss or take-profit conditional order rests on the book instead of executing immediately.
- Exported new `OrderPlacedEventData` / `OrderPlacedEventDataSchema` types describing the placed order's price, quantity, side, and sequencing fields.
- Exported new `StopLossOrderPlacedDetails` / `StopLossOrderPlacedDetailsSchema` and `StopLossOrderPlacedNotification` types, with `filledBaseAmount` / `filledQuoteAmount` present only when the order was partially filled before resting.
- `EventNotificationType` and `EventNotificationItem` now include this new variant; `NotificationItemSchema` parses it via the existing discriminated union.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- If you exhaustively switch over `EventNotificationType` or `EventNotificationItem` (e.g. a `switch` with no `default`), add a case for `"stop_loss_order_placed"` to keep exhaustiveness checks passing.
- `filledBaseAmount` and `filledQuoteAmount` are independently optional on `StopLossOrderPlacedDetails` — both are omitted when the order rested in full, so don't assume they always appear together.

## v0.5.7 - 2026-09-14

Source Phoenix commit: `6826b06a0d967b9b926b6328302508546b62f573`

### Summary

- Added optional `transferSpotCollateralAmounts` to `PlaceIsolatedLimitOrderRequest`, `PlaceIsolatedLimitOrderWithConditionalsRequest`, and `PlaceIsolatedMarketOrderRequest`, letting callers fund isolated positions by transferring specific whole native-unit amounts of one or more spot assets (keyed by symbol) alongside the existing `transferAmount`.
- Corresponding Zod schemas validate each amount as a non-negative integer; the field stays optional so existing requests are unaffected and the API applies its own empty default when omitted.
- Relaxed the `nanoid` dependency constraint from an exact pin (`3.3.17`) to a caret range (`^3.3.17`).
- Version bump to `0.5.7`.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `transferSpotCollateralAmounts` values must be non-negative integers in native units (e.g. lamports/base units), not decimal quantities — fractional or negative values will fail schema validation.
- No action needed to adopt this release; the new field is additive and optional across all three isolated order request types.

## v0.5.6 - 2026-09-14

Source Phoenix commit: `cac9d3de728d31bf20f2a9499f03866c305e2958`

### Summary

- Fixed `computeSubaccountMarginFromInputs` in the margin module to include unsettled funding when computing portfolio value, correcting the `portfolioValueQuoteLots` output for accounts with outstanding funding payments.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- Accounts with nonzero unsettled funding will now receive a different (corrected) `portfolioValueQuoteLots` value from margin computations. No code changes are required, but any downstream logic or UI relying on the previous figure should expect the new, more accurate value.

## v0.5.5 - 2026-09-14

Source Phoenix commit: `ed72a550627c627071186971830394234127b4ce`

### Summary

- Bumped the `nanoid` dependency to `3.3.17` (from `3.3.16`).
- No changes to public TypeScript exports, types, or runtime behavior in this release.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- No consumer action required; the `nanoid` bump is a transitive dependency patch update with no known API impact.

## v0.5.4 - 2026-09-14

Source Phoenix commit: `0d813c3c049a7056761c6f8edf744cadc35d1807`

### Summary

- `TimeWeightedReturnsResolution` now supports two additional finer-grained values, `"5m"` and `"15m"`, alongside the existing `"1h"`, `"4h"`, `"1d"`, `"1w"`, and `"1M"`.
- Consumers calling `getTraderTimeWeightedReturns` can now request 5-minute and 15-minute resolution buckets for time-weighted returns data.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- This is an additive, backward-compatible change — existing `TimeWeightedReturnsResolution` values continue to work unchanged.
- No consumer code changes are required to adopt this release; update if you want to take advantage of the new `"5m"` / `"15m"` resolutions.

## v0.5.3 - 2026-09-14

Source Phoenix commit: `19f87e1e6e19bf4ad42ce4e9489a8cad4fde0bcc`

### Summary

- `TimeWeightedReturnsResponse` (and its Zod schema) now includes a new `returnStartTime: string | null` field indicating the actual start of the return calculation window.
- `TimeWeightedReturnsResolution` no longer accepts the `"15m"` interval — supported resolutions are now `"1h" | "4h" | "1d" | "1w" | "1M"`.

### Breaking Changes

- `TimeWeightedReturnsResolution` dropped the `"15m"` value. Any code requesting or type-checking against a `"15m"` resolution for time-weighted returns will no longer compile and must switch to `"1h"` or coarser.
- `TimeWeightedReturnsResponse` gained a new required field `returnStartTime` (`string | null`). Code that constructs literal objects of this type (e.g. test fixtures, mocks) will need to add this field to satisfy the type.

### Consumer Notes

- When consuming `TimeWeightedReturnsResponse`, use the new `returnStartTime` field to determine when return accrual actually began for the requested window, rather than assuming it matches the requested start time.

## v0.5.2 - 2026-09-14

Source Phoenix commit: `1a0ff4c19848f92d519f3cb8db7e597a952f165f`

### Summary

- `PlaceIsolatedMarketOrderRequest` (and its Zod schema) now accepts an optional `minQuoteLotsToFill` field, alongside the existing `minBaseLotsToFill`, letting callers set a minimum quote-lot fill threshold for isolated market orders.
- Both `minBaseLotsToFill` and `minQuoteLotsToFill` continue to accept `0` explicitly (for true IOC orders) while remaining optional and defaulting to `undefined` when omitted.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `minQuoteLotsToFill` is optional and additive — existing integrations that don't set it are unaffected.
- If you need a minimum quote-lot fill guarantee on isolated market orders (in addition to or instead of a base-lot minimum), pass `minQuoteLotsToFill` in your request.
- Package version bumped to `0.5.2`.

## v0.5.1 - 2026-09-14

Source Phoenix commit: `5100f32502e7cc3217008f7b99e7038661c32777`

### Summary

- Added a new `SpotCollateralValue` type/schema (`assetIndex`, `balance`, `notional`, `discounted`) and exported it from `public-api-schemas`.
- `PortfolioValueDataPoint` gained an optional `spotCollaterals` map (`Record<string, SpotCollateralValue>`, nullable/optional) alongside the existing `positions` map.
- `TraderStateSpotCollateral` gained a new `decimals: number` field describing native-unit decimals for the asset (e.g. 9 for SOL).
- Bumped package version to `0.5.1` and added `undici` as a runtime dependency.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `TraderStateSpotCollateral` responses now always include `decimals`; if you construct or mock this type manually (e.g. in tests), add the field to stay compatible with the schema.
- The new `spotCollaterals` field on `PortfolioValueDataPoint` is optional/nullable, so existing consumers don't need changes unless they want to read per-asset collateral valuation data.

## v0.5.0 - 2026-09-14

Source Phoenix commit: `72cb240e31283f3518f5f5f9ee4f2a64bfd89be2`

### Summary

- Added native SOL spot collateral support: new instruction builders (`buildSyncNativeIx`, `buildWithdrawNativeSolIx`, `buildTransferNativeSolIx`, `buildTransferNativeSolFromChildToParentIx`, `buildLiquidateNativeSolIx`, `buildSwapNativeIx`) and related encoders/types exported from `../core/ixBuilders/NativeSol`.
- Added a new `/v1/collateral/assets` REST endpoint (`V1CollateralClient.getAssets`) and `CollateralAssetMetadata`/`SpotAssetConfig` schemas describing per-asset spot collateral configuration.
- `GlobalConfiguration` now decodes a `nativeSolSpotMetadata` field, and `Trader` accounts now decode `nativeSolCollateral` and a `disablePositionAuthoritySwap` preference bit.
- Exchange snapshots/WebSocket deltas gained an optional `spotCollaterals` field and a new `spotCollateralsUpdated` delta op; the exchange cache exposes a `spotCollaterals()` selector.
- `createMarginCalculator` now accepts an optional second `spotCollaterals` argument, and margin inputs/results gained fields (`nativeSolCollateralLamports`, `spotCollateralBalances`, `pricingMarketSymbol`, `nativeUnitsPerBaseLot`, `retainedBps`) to value spot collateral against a market's index price.
- Added `getPhoenixNativeSolAuthorityAddress` PDA helper and a `NativeSolAuthorityAddress` branded address type.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- Spot collateral valuation requires an index price (`indexPriceTicks`); it is never derived from mark price, so callers must supply it explicitly to value native SOL collateral or margin/liquidation calculations for it will fail or omit spot collateral.
- These instructions and account fields require the corresponding on-chain program upgrade (Rise program bumped `0.3.6` → `0.4.0`); calling the new builders against an older deployed program will fail.
- `MarginMarketParamsStore` can now discover active spot collateral automatically via an optional `collateral` client (`getAssets`); if the server doesn't yet expose `/v1/collateral/assets`, the store degrades gracefully to zero spot collateral rather than failing the whole refresh.

## v0.4.78 - 2026-09-14

Source Phoenix commit: `c9987c1e77e75c7ded83bcd29446f9255fbb600c`

### Summary

- Added `getTraderTimeWeightedReturns(traderPubkey, request)` to `V1TradersClient`, exposing the `GET /v1/traders/{traderPubkey}/time-weighted-returns` endpoint.
- Added new exported types and Zod schemas: `TimeWeightedReturnsRequest`, `TimeWeightedReturnsResponse`, `TimeWeightedReturnPoint`, `TimeWeightedReturnScope`, `TimeWeightedReturnWindow`, `TimeWeightedReturnQuality`, `TimeWeightedReturnCompleteness`, and `TimeWeightedReturnsResolution`, along with their corresponding `*Schema` exports.
- Response fields for timestamps, `userId`, and `resetCount` are normalized to `string` (via a shared JSON-safe integer transform) to preserve values beyond `Number.MAX_SAFE_INTEGER`.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- This is a purely additive endpoint/type release — existing methods and types are unchanged, so no consumer code should require updates.
- When calling `getTraderTimeWeightedReturns`, expect large integer-like fields (`scope.userId`, `quality.resetCount`, and all timestamp fields) to arrive as `string`, not `number` — parse them accordingly if doing arithmetic.
- `resolution` accepts `"15m" | "1h" | "4h" | "1d" | "1w" | "1M"`; `startTime`/`endTime`/`limit` are optional and reused from `HistoricalValuesRequest`.

## v0.4.77 - 2026-09-14

Source Phoenix commit: `5ea2e8690ca50cdeca209b0e3a92c01e27badfbd`

### Summary

- Renamed the `spotAssetParamsByIndex` option to `spotCollateralParamsByIndex` on `MarginSnapshotOptions`, used by `buildSubaccountMarginInputsFromSnapshot`.
- Bumped transitive dependency overrides (`brace-expansion` to `>=5.0.9`, `postcss` to `>=8.5.23`).

### Breaking Changes

- `MarginSnapshotOptions.spotAssetParamsByIndex` has been renamed to `spotCollateralParamsByIndex`. Any caller passing this option to `buildSubaccountMarginInputsFromSnapshot` must update the field name; the old name is no longer recognized and spot collateral params passed under it will be silently ignored.

### Consumer Notes

- No action needed for the `brace-expansion`/`postcss` override bumps unless you pin these transitive versions yourself.

## v0.4.76 - 2026-09-14

Source Phoenix commit: `116538d2560135ebd0d7d11fbb8804d32db043d8`

### Summary

- Added spot collateral margin support: `SpotCollateralMarginInput`/`SpotCollateralMarginResult` types, a `spotCollaterals` field on `SubaccountMarginInputs`, and matching valuation logic in `computeSubaccountMarginFromInputs` that discounts spot balances (e.g. SOL) into effective collateral while including full notional in portfolio value.
- `MarginTotals` and `SubaccountMarginResult` gained optional `spotCollateralNotionalQuoteLots`, `spotCollateralDiscountedQuoteLots`, and `spotCollaterals` fields, populated only when spot collateral inputs are supplied.
- `buildSubaccountMarginInputsFromSnapshot` and `buildTraderMarginInputsFromSnapshot` accept a new optional `options.spotAssetParamsByIndex` argument to map raw traderState spot balances into valued margin inputs using per-asset pricing/discount curve parameters.
- `PlaceIsolatedMarketOrderRequest` (and its Zod schema) gained an optional `minBaseLotsToFill` field for specifying a minimum fill quantity on isolated market orders.
- Isolated-scope margin building now reuses `cloneSubaccountInput`, so scoped cross-margin requests also carry through `spotCollaterals` when present.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- All new fields and function parameters are optional and additive; existing calls to `buildSubaccountMarginInputsFromSnapshot`, `buildTraderMarginInputsFromSnapshot`, and `computeSubaccountMarginFromInputs` continue to work unchanged and omit the new spot-collateral output fields when no spot inputs are given.
- To value spot collateral (e.g. SOL) in margin calculations, pass `spotCollaterals` on `SubaccountMarginInputs` directly, or supply `spotAssetParamsByIndex` (sourced from `/v1/collateral/assets`) when building inputs from a traderState snapshot.
- Spot collateral backs cross margin only — isolated-scope margin inputs drop `spotCollaterals`, and spot value is excluded from `effectiveCollateralForWithdrawalsQuoteLots`.
- `minBaseLotsToFill` on isolated market orders is optional; omitting it preserves prior fill-or-kill default behavior.

## v0.4.75 - 2026-09-14

Source Phoenix commit: `8b82f4267044e45cd33050bf86138e845866e049`

### Summary

- Added spot collateral balance support: new `SpotCollateralBalance` type and `SpotCollateralBalanceSchema`, exported from both `_exports/public-types.ts` and `types/index.ts`.
- `TraderView` now includes an optional `spotCollaterals` field (`SpotCollateralBalance[]`, defaults to `[]`) alongside the existing `collateralBalance`.
- Trader-state WebSocket snapshots and deltas gained a new `TraderStateSpotCollateral` shape (`assetIndex`, `symbol`, `balance`) and an optional `spotCollaterals` array on `TraderStateSubaccountSnapshot` / `TraderStateSubaccountDelta`.
- `TraderStateManager` now tracks `spotCollaterals` through subaccount state construction, snapshot/delta application, and initial state, defaulting to an empty array when absent.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- All new fields are additive and optional (default `[]`), so existing consumers deserializing `TraderView` or trader-state snapshots/deltas do not need code changes.
- Consumers who want per-asset spot collateral detail (balance, notional, discounted, withdrawable) can start reading `TraderView.spotCollaterals` or `TraderStateSubaccountState.spotCollaterals`.

## v0.4.74 - 2026-09-14

Source Phoenix commit: `e5cc47a90b5069779e5e5b647a1ce07d446b31bf`

### Summary

- Bumped `@ellipsis-labs/rise` package version to `0.4.74`.
- Added `brace-expansion` to the workspace's Bun `minimumReleaseAgeExcludes` list in `bunfig.toml`, an internal install-tooling adjustment with no effect on the published package.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- None identified in the synced diff.

## v0.4.73 - 2026-09-14

Source Phoenix commit: `78c281b8371c6653c52b1dfe4e57873beabde5d9`

### Summary

- Added Flight support for **position-authority (delegate-signed) orders**: when a trader's delegate key signs instead of the owner, `client.ixs` order methods now automatically route the wrap through a new collateral-transfer path (`AuthorizedTransferCollateral`) so builder fees can still be collected. Pass the delegate as `positionAuthority` — the effective signer (`positionAuthority ?? authority`) determines the routing automatically.
- The Phoenix root authority needed for this path is resolved live from the exchange metadata snapshot at wrap time (never cached), so on-chain authority rotations are picked up automatically.
- Added new public PDA helpers `flight.getFlightCollateralTransferAuthorityAddress` and `flight.getFlightAuthorizedCollateralTransferPermissionAddress`, and a new `AUTHORIZED_TRANSFER_COLLATERAL` discriminant.

### Breaking Changes

- `PhoenixFlightClient.tryWrapFlightInstruction(ix, authority)` is renamed to `tryWrapOrderInstruction(ix, signer, usePositionAuthority = false)`. Its return type also changed from `ProxyInstructionIx` to the more general `InstructionsWithAccountsAndData`.
- `flight.wrapInstructionWithFlight(...)` renamed its `authority` parameter to `signer`, and added `usePositionAuthority` / `resolveRootAuthority` options — callers using named-argument objects must update the key.
- The invalid fee-bps-override error message text changed from `"Fee bps override must be in the range 0..=10000"` to `"Invalid fee bps override (must be in 0..=10000)"`; update any code that pattern-matches on the message.

### Consumer Notes

- `ClientPlaceMarketOrderDelegatedInput.traderWallet` is now deprecated in favor of `positionAuthority`, the shared field name used across all placement inputs.
- Owner-signed orders (including owner-signed `PlaceMarketOrderDelegated`) are unaffected — they continue to wrap without the collateral-transfer tail.
- See the updated `ts/src/flight/README.md` "Position-Authority (Delegate-Signed) Orders" section and `ts/examples/06-flight-market-order.ts` (`POSITION_AUTHORITY` env var) for migration examples.

## v0.4.72 - 2026-09-14

Source Phoenix commit: `6e87cca0c94f2daf3f64938b475bb0dc43564ecc`

### Summary

- Bumped `@ellipsis-labs/rise` to `0.4.72`.
- Raised the minimum supported `postcss` version from `>=8.5.10` to `>=8.5.12` (bundled/lockfile `postcss` updated to `8.5.19`, `nanoid` to `3.3.16`).

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- If you pin or override `postcss` in your project, ensure it satisfies `>=8.5.12` to remain compatible with this release.
- No public API, export, or runtime behavior changes in this release.

## v0.4.71 - 2026-09-14

Source Phoenix commit: `ff2af96c827a5f84b2d87c1b5e986cf86cd10988`

### Summary

- Bumped the `brace-expansion` dependency override from `5.0.6` to `5.0.7`.
- Released as `@ellipsis-labs/rise` v0.4.71.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- No public API, type, or runtime behavior changes; this release only updates a transitive dependency override.
- No consumer action required beyond picking up the new package version.

## v0.4.70 - 2026-09-14

Source Phoenix commit: `aae588cdd4469d444096f6a1db17803c687ec72a`

### Summary

- Added a new draft order margin API: `computeDraftOrderMarginRequirementFromInputs` / `computeDraftOrderMarginRequirementFromSnapshot`, which return the incremental initial margin a draft limit or market order would require, including an order-leverage-adjusted value when `orderLeverageLimitsBySymbol` applies.
- Added `computeMaxDraftOrderSizeForAvailableMarginFromInputs` / `computeMaxDraftOrderSizeForAvailableMarginFromSnapshot` to binary-search the largest draft order size that fits a given available margin budget, with reduce-only market orders automatically capped to the closable position size.
- Exported new supporting types: `DraftOrderMarginInput`, `DraftOrderMarginRequirementResult`, `MarginMarketsInput`.
- `getOrCreateMarketInput`, `ensureOrderListCanBeMutated`, and `cloneSubaccountInput` are now exported from `margin/compute.ts` for use by the new draft order helpers.
- `buildNormalizedMarketParamsBySymbol` (and its internal tier parser) now accept `readonly MarketParams[]` instead of `MarketParams[]`, a strictly more permissive input type.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- Use the new `computeDraftOrderMarginRequirement*` functions to price a draft order's margin impact before submission, and `computeMaxDraftOrderSizeForAvailableMargin*` to size an order against available margin — both come in `FromInputs` (already-built `SubaccountMarginInputs`) and `FromSnapshot` (raw snapshot) variants, matching the existing pattern used by other margin calculators in the package.
- `marginRequirementQuoteLots` already reflects any order-leverage adjustment; use `protocolMarginRequirementQuoteLots` if you need the unadjusted protocol value.
- The `readonly MarketParams[]` widening is source-compatible — existing calls passing a mutable array continue to work unchanged.

## v0.4.69 - 2026-09-14

Source Phoenix commit: `68ec7e66b25a869e95ba56ac5bca31fbdef2209d`

### Summary

- Added `buildFlameAtomicDepositFlow`, a new flow that bundles Flame proxy funding, permission setup, and the Flame `DepositToPhoenix` instruction into one atomic, sponsor-payable deposit.
- Added the underlying `buildFlameDepositToPhoenixIx` instruction builder plus `deriveFlameDepositToPhoenixAddresses` and `deriveFlameGlobalStateAddress` address helpers, all exported from the package root.
- Added a new `DEPOSIT_PERMISSION` bitflag constant alongside the existing trader onboarding/management permissions.
- Sponsors act as the crank/fee payer for the new deposit instruction, fronting rent for a transient proxy Phoenix ATA that is refunded on close within the same instruction, so wallets with no SOL can complete a deposit.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `buildFlameAtomicDepositFlow` currently only supports `traderSubaccountIndex: 0`; passing any other value throws `"Flame atomic deposit sponsorship only supports traderSubaccountIndex 0"`.
- `buildDepositFlow` is unchanged and remains the direct Ember + Phoenix deposit path; use the new flow only when you need a single-transaction sponsored deposit via Flame.

## v0.4.68 - 2026-07-10

Source Phoenix commit: `3343d458b9162061b4f810408bee2b14bcdf6af0`

### Summary

- Added typed market-stats endpoints to `V1MarketsClient`: `getLatestMarketStats(symbol)` and `getLatestMarketsStats()`, backed by new exported `LatestMarketStatsResponse`/`LatestMarketsStatsResponse` types and Zod schemas.
- Added `resolvePhoenixBuilderAddresses` (with `PhoenixBuilderAddressDefaults` and `ResolvePhoenixBuilderAddressesInput` types) to resolve a complete per-environment address set — program, log authority, global configuration, USDC mint, and ember state — in a single call.
- Added new exported constants `EMBER_STATE_ADDRESS` and `BETA_USDC_MINT_ADDRESS`.
- Bumped `@ellipsis-labs/rise` from `0.4.66` to `0.4.68`, syncing Phoenix `0.4.68` (phoenix-rise Rust crates bumped `0.3.4` → `0.3.5`).
## v0.4.67 - 2026-07-09

Source Phoenix commit: `39520ccb1d19d0f7610909dd2718dc7918d0ec22`

### Summary

- Added `getLatestMarketStats(symbol)` to `V1MarketsClient` for fetching the latest stats snapshot for a single market via `GET /v1/market/{symbol}/stats/latest`.
- Added `getLatestMarketsStats()` to `V1MarketsClient` for fetching the latest stats snapshot across all markets via `GET /v1/markets/stats/latest`.
- Exported new response types and Zod schemas: `LatestMarketStatsResponse`, `LatestMarketStatsResponseSchema`, `LatestMarketsStatsResponse`, `LatestMarketsStatsResponseSchema`.
- `LatestMarketStatsResponse` includes `mark_price`, `oracle_price`, `prev_day_mark_price`, `open_interest`, `day_volume_usd`, `day_volume_base`, `current_funding_rate`, `eight_hour_funding_rate`, and `annualized_funding_rate`.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- For beta-environment instruction building, prefer `resolvePhoenixBuilderAddresses` over manually assembling addresses — it prevents silently falling back to the mainnet USDC mint when targeting beta.
- `LatestMarketStatsResponse.timestamp_ms` is typed and parsed as `bigint` (accepting numeric or string input, consistent with other big-integer fields in the SDK).
- `timestamp_ms` on the new response types is parsed as a `bigint` using the same big-integer schema used elsewhere in the SDK. It accepts `string`, `number`, or `bigint` input, but rejects non-integer numbers and numeric values beyond `Number.MAX_SAFE_INTEGER` — pass large timestamps as strings to avoid precision loss.
- `getLatestMarketsStats()` returns `{ markets: LatestMarketStatsResponse[] }`.

## v0.4.66 - 2026-07-08

Source Phoenix commit: `6051225fb045fbb5b6a454bd445e7fc2e31e5722`

### Summary

- Rewrote the SDK's liquidation-price search to use a numeric mark-price boundary search instead of the previous closed-form equation, fixing incorrect results for already-liquidatable positions and for same-market resting orders.
- Added a new "projected liquidation" API — `computeProjectedLiquidation`, `computeMarketProjectedLiquidationFromMargin`, `computeSubaccountProjectedLiquidationFromMargin`, `createProjectedLiquidationCalculator`, `aggregateLimitOrderStateFromOrders`, and related types — that estimates liquidation risk after a trader's own resting orders fill along the adverse price path.
- Limit-order margin best-bid/best-ask sentinels are now computed relative to the current mark price via the new `buildLimitOrderMarginStateFromOrdersAtMark`, so only orders that could actually cross at the current mark reserve fill-loss margin.

### Breaking Changes

- `computeMarketLiquidationPriceFromMargin`, `computeSubaccountLiquidationPricesFromMargin`, and `computeTraderLiquidationPricesFromMargin` now return the current mark price for already-liquidatable positions and otherwise use the new boundary-search algorithm — expect different numeric outputs than 0.4.65 for identical inputs.
- `buildMarketMarginInputsFromSnapshot` no longer populates `limitOrderMargin` on its returned `MarketMarginInputs`; margin/liquidation computation now derives limit-order sentinels internally from `limitOrders` and the market's mark price. Code reading `.limitOrderMargin` directly off this helper's output will now see `undefined`.
- Same-market limit-order maintenance margin is now mark-price-dependent (only crossing-side resting orders count toward fill-loss margin), changing computed margin/liquidation values for accounts with resting orders on the far side of the mark.

### Consumer Notes

- Treat the existing static liquidation-price functions as the canonical current-state ("Hawkeye-compatible") value; use the new projected-liquidation functions only for scenario/risk displays, not for liquidation-eligibility or program parity checks.
- `calculateLiquidationPriceUsd` gained an optional `targetLimitOrderMaintenanceCoefficient` input, defaulting to `0` for backward compatibility.
- `buildLimitOrderMarginStateFromOrders` keeps its prior signature/behavior for existing callers; switch to `buildLimitOrderMarginStateFromOrdersAtMark` where mark-relative sentinels are needed.

## v0.4.65 - 2026-07-07

Source Phoenix commit: `25625a376965069d216ba53f8bbf0457f097a927`

### Summary

- Margin calculations now reserve additional collateral for resting limit orders priced adversely to the mark price (an "adverse fill-loss" reserve), mirroring the on-chain `program-core` margin logic.
- Reduce-only order margin reserves are now capped by the size of the opposite-side position they can actually reduce, preventing over-reservation for large reduce-only orders against small positions.
- `LimitOrderMarginState` and the internal margin aggregation helpers gained new fields (best bid/ask, reduce-only totals) to support the fill-loss calculation.

### Breaking Changes

- `LimitOrderMarginState` now requires `numAskOrders`, `numBidOrders` (previously optional), plus new required fields `lowestAsk`, `highestBid`, `totalReduceOnlyAskBaseLots`, and `totalReduceOnlyBidBaseLots`. Code that constructs this type directly (e.g. passing `limitOrderMargin` as a computed-margin input) must supply all of these fields or compilation/runtime behavior will differ.
- `buildLimitOrderMarginStateFromOrders` gained a second parameter, `basePositionLots`, used to cap reduce-only reserves against the opposite position. It defaults to `0n`, so existing calls still compile, but omitting it means reduce-only orders are treated as fully reducing a zero position (capped to zero) rather than uncapped as before.

### Consumer Notes

- Accounts with resting limit orders priced away from mark should expect `initialMarginQuoteLots` and `limitOrderMarginQuoteLots` from `computeSubaccountMarginFromInputs` (via `createMarginCalculator`) to increase, since adverse-fill-loss is now included in the reserve.
- If you rely on `buildLimitOrderMarginStateFromOrders` for reduce-only sizing, pass the account's current `basePositionLots` (signed, base lots) as the second argument to get correctly capped reserves instead of the new zero-position default.
- Callers that only supply `limitOrders` (not a precomputed `limitOrderMargin`) need no changes — the new fields are derived automatically from order data and position size.

## v0.4.64 - 2026-07-06

Source Phoenix commit: `84c3feb1a2f5d9b4e94f9372a706b0e3e3c88b0e`

### Summary

- Added a liquidation price calculator (`calculateLiquidationPriceUsd`) plus helpers to compute per-market, per-subaccount, and per-trader liquidation prices from margin results or raw inputs (`compute*LiquidationPricesFrom{Inputs,Margin}`, `computeMarketLiquidationPriceFromMargin`).
- Added a margin simulation API (`simulateMarginFromInputs`, `simulateMarginScenariosFromInputs`, `simulatePositionFillFromInputs`) with actions for fills, position closes, limit orders, collateral/funding adjustments, and mark-price moves, including projected liquidation prices.
- `MarginCalculator` (from `createMarginCalculator`) gained corresponding instance methods: `computeTraderLiquidationPricesFromInputs`, `computeSubaccountLiquidationPricesFromInputs`, `simulateMargin`, `simulateMarginScenarios`, `simulatePositionFill`.
- Fixed leverage-tier interpolation (`getLeverageConstant`, `getLimitOrderRiskFactor`) to use floating-point interpolation matching the Rust program instead of bigint truncation.
- Internal `marginParityExport.ts` dev script was refactored to reuse the new liquidation module; no public API impact.

### Breaking Changes

- Interpolated leverage and limit-order risk-factor values for position sizes strictly between leverage-tier bounds can now differ slightly from prior output, since `getLeverageConstant`/`getLimitOrderRiskFactor` switched from bigint-truncated interpolation to Rust-matching floating-point interpolation. Consumers asserting exact previous intermediate values should re-verify them.

### Consumer Notes

- New exports: `calculateLiquidationPriceUsd`, `computeMarketLiquidationPriceFromMargin`, `computeSubaccountLiquidationPricesFromInputs`/`FromMargin`, `computeTraderLiquidationPricesFromInputs`/`FromMargin`, `simulateMarginFromInputs`, `simulateMarginScenariosFromInputs`, `simulatePositionFillFromInputs`, and their associated types.
- The liquidation-price helpers throw on inconsistent margin totals (maintenance-margin underflow between portfolio and position-only figures) rather than silently clamping — validate margin snapshots before calling these in production paths.
- Margin simulation actions (`fillPosition`, `closePosition`, `placeLimitOrder`, `cancelOrder`, `cancelAllOrders`, `adjustCollateral`, `setCollateral`, `settleFunding`, `applyFundingPayment`, `setMarkPrice`, `moveMarkPrice`) support building what-if previews (e.g. order tickets, price ladders) against cross or isolated margin scopes.

## v0.4.63 - 2026-07-06

Source Phoenix commit: `014384041aa15c0f02a8a5277745b907ae510ee4`

### Summary

- Added an optional `options` parameter (`MarginCalculationOptions`) to `computeTraderMargin`, `computeSubaccountMargin`, `computeTraderMarginFromInputs`, `computeSubaccountMarginFromInputs`, and the corresponding `MarginCalculator` methods, letting callers pass per-symbol order leverage preferences via `orderLeverageLimitsBySymbol`.
- Order leverage limits are applied only to order/limit-order sizing math (initial margin from open orders, limit order margin requirements); position-only margin, withdrawal margin, maintenance/backstop/high-risk margin, and risk state/tier are always computed from protocol leverage tiers, unaffected by the new option.
- `MarginTotals` gains an optional `orderLeverageAdjustedInitialMarginQuoteLots` field, and `OrderMarginResult` gains an optional `orderLeverageAdjustedMarginRequirementQuoteLots` field; both are omitted entirely when no limit is supplied or when the adjusted value matches the protocol value.
- Limit values are validated defensively: non-finite, non-integer-safe, sub-1, or above-protocol-max values are silently ignored and fall back to protocol leverage; valid fractional values floor to the nearest integer leverage.
- Calling existing margin functions with no `options` argument (or an empty options object) produces byte-identical output to the prior release.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- All new behavior is opt-in via the new `options` parameter — no changes are required to existing integrations.
- Consumers that want to preview reduced-leverage order/margin requirements (e.g. surfacing a lower "order leverage" preference in UI) can pass `{ orderLeverageLimitsBySymbol: { "SOL-PERP": 5 } }` and read the new `orderLeverageAdjusted*` fields where present; treat their absence as "no adjustment applies."
- Do not rely on `orderLeverageAdjustedInitialMarginQuoteLots` for withdrawal eligibility or risk-state checks — those continue to use protocol-only margin figures.

## v0.4.62 - 2026-07-02

Source Phoenix commit: `e427d47ea42afce753295b0559ac3a0e8c505518`

### Summary

- `buildCancelOrdersById` / `cancelOrdersById` now accept an optional `priceInTicks` field on each order, letting you cancel orders using the tick price returned by `placeLimitOrder`/order-state APIs instead of converting through a USD price.
- Market tick-size and base-lot-decimals metadata is now only required when cancelling orders via the legacy `price` (USD) field; tick-native cancels work even when that market metadata isn't resolved.
- Added `getCancelOrdersByIdDecoder` and `getCancelOrdersByIdCodec` exports alongside the existing `getCancelOrdersByIdEncoder`, enabling round-trip decoding of `CancelOrdersById` instruction data.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- The `price` field on cancel-by-id orders is now deprecated in favor of `priceInTicks`; existing code using `price` continues to work unchanged, but new integrations should prefer `priceInTicks` to avoid tick/USD conversion entirely.
- If you build cancel-by-id instructions purely from `priceInTicks`, you no longer need to ensure `tickSize`/`baseLotsDecimals` are present in your resolved market context.

## v0.4.61 - 2026-07-02

Source Phoenix commit: `64e433145ad2776c55d9ca53762ecfa78ba3ed51`

### Summary

- Added an optional `feePayer` field to `PlaceMultiLimitOrderFlowParams`. For isolated-margin multi-limit orders that require registering a fresh child subaccount, this account now pays the trader-account rent and signs the register instruction, instead of always defaulting to `authority`.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `feePayer` is optional and defaults to previous behavior (`authority`) when omitted, so existing calls to `buildPlaceMultiLimitOrderFlow` are unaffected.
- If you place isolated-margin multi-limit orders through sponsored and/or delegated sessions — where neither the sponsor nor the delegate can sign for `authority` — pass a `feePayer` to cover trader-account rent and the register signature; otherwise flows that need to register a new child subaccount in that setup will fail.

## v0.4.60 - 2026-07-01

Source Phoenix commit: `cf8419bc21f9f539306198f7c08d0aca14a39580`

### Summary

- Adds a trader preferences bitfield: new `TraderPreferenceKind` enum, `encodeTraderPreferences`/`decodeTraderPreferenceFlags` helpers, and related constants/types for setting and reading per-trader flags (currently just `disableCollateralSweep`).
- `decodeTrader` output now includes `traderPreferenceFlags`, `preferences`, and `disableCollateralSweep` alongside the existing raw `traderPreferenceBits`.
- `buildRegisterTraderIx`/`buildRegisterTraderIxResolved` accept new optional `traderPreferenceBits`, `traderPreferences`, and `disableCollateralSweep` params to set preferences at registration time.
- Fixes trader position-map decoding so entries carrying a non-zero upper-bits discriminant (previously silently dropped) are now correctly included as position entries.
- Tightens `RegisterTrader` param validation: `traderPdaIndex` and `traderSubaccountIndex` must now be integers within explicit bounds (0–255 and 0–100 respectively).

### Breaking Changes

- `RegisterTrader` instruction wire format changed: `maxPositions` is now encoded as a `u32` (was `u64`), and a new `u32` `traderPreferenceBits` field is inserted before `traderPdaIndex`/`subaccountIndex`. Any code building raw instruction bytes manually, or relying on a cached/stale IDL for this instruction, must update to the new layout.
- `buildRegisterTraderIx` now throws for a `traderSubaccountIndex` outside `0–100` (previously unvalidated) and for non-integer `traderPdaIndex`/`traderSubaccountIndex` values; calls that previously succeeded with such inputs will now throw.
- The `traderPdaIndex` validation error message changed from `"Trader PDA index must be between 0 and 255"` to `"Trader PDA index must be an integer between 0 and 255"` — code matching on the exact string will break.

### Consumer Notes

- To disable collateral sweep for a trader, pass `disableCollateralSweep: true` (or `traderPreferences: [TraderPreferenceKind.DisableCollateralSweep]`) to `buildRegisterTraderIx`/`buildRegisterTraderIxResolved`.
- Existing decoded `Trader` accounts gain `preferences.disableCollateralSweep` and `traderPreferenceFlags` (with `bits`, `enabled`, `reservedBits`, `hasReservedBits`) for inspecting preference state without manual bit-masking.
- If your app reads `positions.entries` from decoded `Trader` accounts, expect entry counts/contents to change for accounts holding position-map entries with a non-zero discriminant in the upper 32 bits — these are now surfaced as position entries where they were previously silently skipped.

## v0.4.59 - 2026-06-30

Source Phoenix commit: `e6a5f77bd8cbda7bddfa2e8687408ce87237aa0f`

### Summary

- Routine sync from Phoenix `0.4.58` to `0.4.59`. The synced diff only touches the package version bump and internal localnet test-harness/test files (`ts/tests/test-harness/localnet.ts`, `ts/tests/sdk-localnet-flows.test.ts`) — no changes to published package source were included.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- None identified in the synced diff.

## v0.4.58 - 2026-06-30

Source Phoenix commit: `1fdded8e2b1c9104c74a89a0f8ce79e4ad9a9873`

### Summary

- `Trader.maxPositions` and `SubaccountInfo.maxPositions` now decode as `number` instead of `bigint`, matching the on-chain layout change from a `u64` field to a `u32` field.
- `Trader` gains a new `traderPreferenceBits: number` field occupying the upper 32 bits that were previously part of `maxPositions`.
- `toMaxPositions()` now returns `number` instead of `bigint` (cross → `128`, isolated → `1`).
- `Trader.positions` entries are now decoded with a type-aware decoder that silently skips non-position entries (asset IDs ≥ `0xff000000`); `positions.len` reflects only decoded position entries rather than the raw stored count.

### Breaking Changes

- **`Trader.maxPositions`: `bigint` → `number`** — downstream code comparing or storing this field as `bigint` will fail TypeScript compilation; replace `128n`/`1n` literals with `128`/`1`.
- **`SubaccountInfo.maxPositions`: `bigint` → `number`** — same migration needed for any code that constructs or destructures `SubaccountInfo`.
- **`toMaxPositions()` return type: `bigint` → `number`** — callers passing the result to an instruction parameter expecting `bigint` must now wrap it with `BigInt(toMaxPositions(...))`.

### Consumer Notes

- Add `traderPreferenceBits: number` to any local types that mirror or extend `Trader`; it will be `0` for all existing accounts until the on-chain program populates it.
- If your code compares `positions.len` against the number of decoded entries, note that the two values can now differ when the position map contains header-extension slots; iterate `positions.entries` rather than relying on `positions.len` for the count.

## v0.4.57 - 2026-06-29

Source Phoenix commit: `d087e01780d6f8cfadb10005c6607f7de59d3de2`

### Summary

- New Spline instruction builders (`buildRegisterSplineIx`, `buildDeactivateSplineIx`, `buildUpdateSplinePriceIx`, `buildUpdateSplinePriceWithOrderingIx`, `buildUpdateSplineParametersWithOrderingIx`, `buildUpdateSplinePositionLimitsConfigIx`) plus all associated parameter types, account types, and codecs are now publicly exported.
- `decodePerpAssetMap`, `fetchPerpAssetMap`, and `getPerpAssetMapDecoder` are now exported from the package root.
- `HAWKEYE_DISCRIMINANTS` is now exported from `hawkeye.ts`; `FLIGHT_DISCRIMINANTS` gains five additional entries (`INIT`, `NAME_SUCCESSOR`, `CLAIM_SUCCESSOR`, `UPDATE_GLOBAL_STATE`, `UPDATE_BUILDER_STATUS`); `DISCRIMINANTS` gains five Spline entries.
- Two new test-fixture files (`sdk-account-fixtures.json`, `sdk-instruction-fixtures.json`) are now listed in the package `exports` map and accessible as subpath imports.

### Breaking Changes

- **`MarkPrice.oracleLastUpdatedTimestamps` is now a required field (`bigint[]`).** Previously this field was decoded but silently dropped; it is now part of the public `MarkPrice` interface. TypeScript builds that construct `MarkPrice` objects directly (e.g. in mocks or tests) or that use exhaustive destructuring will fail to compile until the field is added.

### Consumer Notes

- Spline instructions follow the same two-argument pattern as other update builders: `buildUpdateSpline*(accounts: SplineUpdateAccounts, params: ...)`. Register and deactivate take a single params object that includes account fields.
- `clientOrderId` in ordering variants is an optional `Uint8Array` of exactly 16 bytes; omitting it defaults to a zero-filled 16-byte array. `overrideSequenceNumber` defaults to `false` when omitted.
- `MAX_SPLINE_REGIONS` (= 10) is exported as a named constant; `buildUpdateSplineParametersWithOrderingIx` will throw at call-time if either `bidRegions` or `askRegions` exceeds this limit, or if both arrays are empty.
- `PositionSizeLimit` is a discriminated union `{ __kind: "Disabled" } | { __kind: "Limit"; value: PositionSizeLimits }`; pass `null` for `maxPositionSize` or `leverageDecreaseInBps` to leave that field unchanged (at least one must be non-null or the builder throws).

## v0.4.56 - 2026-06-26

Source Phoenix commit: `0034c63597c926482b11094a6ab661ffcc127896`

### Summary

- **Scale order API** (`scaleOrders.ts`) is now exported from the package root: `computeScaleOrderLevels`, `previewScaleOrder`, `scaleLevelsToMultipleOrderPacket`, `chunkScaleLevelsForTx`, their associated types (`ScaleOrderInput`, `ScaleOrderLevel`, `ScaleOrderPreview`, `ScaleOrderWarning`, `ScaleOrderWarningCode`, `ScaleLevelsToPacketOptions`), and constants (`MIN_SCALE_ORDERS`, `MAX_SCALE_ORDERS`, `MIN_SCALE_BIAS`, `MAX_SCALE_BIAS`, `DEFAULT_MIN_BASE_LOTS_PER_ORDER`, `DEFAULT_MAX_ORDERS_PER_TX`).
- **`buildPlaceMultiLimitOrderFlow`** and its four types (`PlaceMultiLimitOrderFlowParams`, `PlaceMultiLimitOrderFlowBatch`, `PlaceMultiLimitOrderFlowBatchInstructions`, `PlaceMultiLimitOrderFlowResult`) are now exported — a high-level flow that handles subaccount allocation, optional registration, collateral transfer, and post-placement sweep for both cross and isolated margin, splitting large ladders across transaction batches automatically.
- **`buildPlaceMultiLimitOrderIxResolved`** / **`BuildPlaceMultiLimitOrderIxResolvedInput`** added alongside the existing resolved instruction builders.
- **`ticksToUsdWithMarketParams`** is now exported from the package root — the inverse of `priceUsdToTicksWithMarketParams`, useful for converting on-chain tick prices back to human-readable USD for display or preview.
- **`AccountFetcherClient`** gains an optional `fetchMaybeAccounts` method; `PhoenixRpcAccountFetcherClient` now implements it, batching up to 100 addresses per `getMultipleAccounts` round-trip and returning `null` for missing accounts.

### Breaking Changes

- **`buildPlaceMultiLimitOrderIx` now marks `globalConfigurationAddress` writable.** The on-chain program requires this account writable; the previous readonly flag caused transactions to be rejected at the program loader. Any caller constructing this instruction manually should update their account-role assumptions.

### Consumer Notes

- Scale ladders larger than `DEFAULT_MAX_ORDERS_PER_TX` (30) produce multiple `PlaceMultiLimitOrderFlowBatch` entries in `PlaceMultiLimitOrderFlowResult.batches`; each batch must be submitted as a separate transaction. Batches are **not atomic across transactions** — a mid-ladder failure can leave a partial position, and for isolated margin, collateral may be funded but not yet swept back to the parent.
- For isolated margin without an explicit `subaccountIndex`, `buildPlaceMultiLimitOrderFlow` requires `transferAmount > 0` to fund the child subaccount; omitting it throws at construction time.
- The `fetchMaybeAccounts` addition to `AccountFetcherClient` is **optional** — existing client implementations that do not implement it continue to work via the per-address fallback path.
## v0.4.55 - 2026-06-25

Source Phoenix commit: `2f2bb2ba1256f28465278ff1c00d61f0ffc2c5f2`

### Summary

- Added two new methods to `V1ExchangeClient`: `buildRegisterIxs` (calls `POST /v1/exchange/build-register-ixs`) and `sendRegisterIxs` (calls `POST /v1/exchange/send-register-ixs`), enabling builders to register and onboard a trader without a referral code.
- Exported six new public types and their Zod schemas from both the package root (`index.ts`) and the public-api-schemas barrel: `BuildRegisterIxsRequest`, `BuildRegisterIxsResponse`, `SendRegisterIxsRequest`, `SendRegisterIxsResponse`, `RegisterIxInstruction`, and `RegisterIxAccountMeta`.
- Added `examples/10-builder-onboarding-tx.ts`, a runnable end-to-end example of the builder onboarding flow: fetch instructions, partially sign locally, submit to the API for co-signing, simulation, and broadcast.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- The builder onboarding flow is two steps: call `client.api.exchange().buildRegisterIxs({ traderAuthority, txFeePayer, maxPositions? })` to receive the instruction list, build and partially sign the transaction, then call `client.api.exchange().sendRegisterIxs({ transaction, traderAuthority, txFeePayer, ... })` to have the API validate, co-sign as onboarder, simulate, and send. `maxPositions` is optional on both calls (32–128; default 128).
- This onboarding path is distinct from the referral-code path (`POST /v1/referral/activate-tx`) and the access-code path (`POST /v1/invite/activate`). Use `build-register-ixs` / `send-register-ixs` when the builder controls the fee payer and no referral code is involved.

## v0.4.54 - 2026-06-25

Source Phoenix commit: `190b6af2b821bd0670b4a1aea8dad552bcd62482`

### Summary

- **Service-account authentication for server-side tools.** `PhoenixAuthClient` gains three new methods — `loginWithServiceAccountSigner`, `loginWithServiceAccountCredential`, and `loginWithServiceAccountFromEnv` — enabling non-interactive authentication using Ed25519 keypair credentials.
- **New public exports from `@ellipsis-labs/rise/auth`:** `PhoenixServiceAccountCredential`, `PhoenixServiceAccountAuthSigner`, `PhoenixServiceAccountAuthClient`, `PhoenixServiceAccountCredentialEnv`, `createServiceAccountAuthSigner`, `loginWithServiceAccountCredential`, `loginWithServiceAccountSigner`, `loginWithServiceAccountFromEnv`, `loadServiceAccountCredentialFromEnv`, and `loadServiceAccountCredentialFromPath`.
- **Env-var credential loading** mirrors the Rise Rust SDK: set `PHOENIX_SERVICE_ACCOUNT_CREDENTIAL` (path to a JSON file) or the split vars `PHOENIX_SERVICE_ACCOUNT_CLIENT_ID` / `PHOENIX_SERVICE_ACCOUNT_KEY_ID` / `PHOENIX_SERVICE_ACCOUNT_PRIVATE_KEY`. Legacy `PHOENIX_SERVICE_CLIENT_ID`, `PHOENIX_SERVICE_KEY_ID`, and `PHOENIX_SERVICE_PRIVATE_KEY` aliases are also accepted.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- Credential file loading (`PHOENIX_SERVICE_ACCOUNT_CREDENTIAL` / `loadServiceAccountCredentialFromPath`) uses `node:fs/promises` and is only available in Node.js and Bun environments; browser bundles that import `loadServiceAccountCredentialFromEnv` with a file path will throw at runtime. Split env-var loading has no Node dependency and works anywhere `process.env` is accessible.
- Partial split-env configuration (some but not all of `CLIENT_ID`, `KEY_ID`, `PRIVATE_KEY` present) throws `PhoenixAuthError` with code `incomplete_service_account_credential_env` rather than silently falling through.
- Private keys must be 32-byte Ed25519 seeds encoded as base64url (no padding); a mismatched length throws `PhoenixAuthError` with code `invalid_service_account_private_key`.

## v0.4.53 - 2026-06-25

Source Phoenix commit: `823bb5e64efafb221f37a7e0a8f8720da843741c`

### Summary

- **Automatic trader account detection**: `buildActivateReferralTxRequest` now accepts optional `rpc` or `rpcUrl` parameters. When provided and `includeRegisterTrader` is not set explicitly, the SDK queries the on-chain trader account and automatically prepends `register_trader` if the account does not exist.
- **Opt-in trader registration in a single transaction**: `buildReferralActivationTransaction` and `buildActivateReferralTxRequest` accept two new optional fields — `includeRegisterTrader: boolean` and `registerTraderMaxPositions?: bigint` (32–128, default 128) — to prepend `register_trader` before delegated onboarding.
- **New utility exports**: `getReferralActivationTraderState` inspects whether a trader PDA is `"missing"`, `"registered"`, or `"activated"`; `hasReferralActivationCapabilities` tests raw trader capability flags.
- **New types exported**: `ReferralActivationRpc`, `ReferralActivationTraderState`, `ReferralActivationTraderStatus`, and `ReferralActivationTransaction`.
- **Enriched result from `buildActivateReferralTxRequest`**: the returned object now includes `includeRegisterTrader: boolean` and `traderActivationState?: ReferralActivationTraderState`.

### Breaking Changes

- `ReferralActivationTransactionBuild.transaction` is now typed as `ReferralActivationTransaction` (`Transaction & TransactionWithLifetime`) instead of plain `Transaction`. Existing callers assigning the result to a `Transaction`-typed variable will still compile, but implementors of `ReferralActivationTransactionSigner` whose callback is explicitly annotated with the old `(transaction: Transaction, ...) => ...` signature may see a type mismatch when the annotation is updated to the new stricter type — update to `ReferralActivationTransaction` or remove the explicit annotation.

### Consumer Notes

- `rentPayer` is still deprecated, but its behavior changed: when `includeRegisterTrader: true` is set and no `feePayer` is provided, `rentPayer` is now used as the fallback fee payer for the registration instruction. Existing callers that pass `rentPayer` without `includeRegisterTrader: true` are unaffected — it continues to be ignored in that case.
- `registerTraderMaxPositions` must be between `32n` and `128n`; passing a value outside this range throws synchronously before any RPC call.
- To use auto-detection, pass `rpc` (a `createSolanaRpc` instance) or `rpcUrl` to `buildActivateReferralTxRequest` and omit `includeRegisterTrader`. The returned `traderActivationState` reflects what the SDK observed on-chain.

## v0.4.52 - 2026-06-25

Source Phoenix commit: `f9c0326d728b06047d21c64915a6a72f8bcb1afb`

### Summary

- Added `withdrawalsAvailable: boolean` to `ExchangeStatusView`, `ExchangeStateSnapshot`, `ExchangeStatusChangedOp`, and `ExchangeStatusPayload` — reflects whether the exchange withdraw queue is open for withdrawals (requires exchange to be active and withdraw throttle budget to be non-zero).
- RPC snapshot loading now fetches the withdraw queue header in parallel, using it to populate `withdrawalsAvailable`; a fetch failure is treated as available (`true`).
- `exchangeUpdated` events in the cache store now include `withdrawalsAvailable`, and a change in its value triggers a `"status"` exchange change notification.
- Wire adapters normalize the snake_case alias `withdrawals_available` from the server to `withdrawalsAvailable`, defaulting to `true` when the field is absent (backward-compatible with older server payloads).

### Breaking Changes

- `ExchangeStatusView`, `ExchangeStateSnapshot`, `ExchangeStatusChangedOp`, and `ExchangeStatusPayload` each gain a required `withdrawalsAvailable: boolean` field. Consumers who construct or assert on these types directly (e.g., in tests or typed fixtures) must add this field. Wire-parsed values from the server default to `true` when the field is missing, so runtime parsing is non-breaking.

### Consumer Notes

- Read `snapshot.exchange.withdrawalsAvailable` or `status.withdrawalsAvailable` to determine whether withdrawals are currently permitted before initiating a withdrawal flow.
- No action needed for pure subscribers: existing server messages without `withdrawalsAvailable` are handled transparently with a `true` default.

## v0.4.51 - 2026-06-24

Source Phoenix commit: `f437eb2cee153f012a3ab34e799623d34defb07f`

### Summary

- Added a transaction-based referral activation flow: `V1InviteClient` now exposes `getReferralActivationPermission()` (`GET /v1/referral/activation-permission`), `activateReferralTx(request)` (`POST /v1/referral/activate-tx`), and `buildActivateReferralTxRequest(params)`, which fetches permission and exchange state automatically, builds the Solana transaction, and invokes a caller-supplied signer callback before returning the ready-to-submit request.
- Exported low-level transaction helpers at the package root for integrators who need finer control: `buildReferralActivationTransaction`, `buildActivateReferralTxRequest`, `referralActivationExchangeAccountsFromSnapshot`, and `serializeReferralActivationSignedTransaction`.
- Added new public types and Zod schemas: `ActivateReferralTxRequest/Response`, `ActivateReferralTxStatus`, `ACTIVATE_REFERRAL_TX_STATUSES`, `ReferralActivationPermissionResponse`, `ReferralActivationExchangeAccounts`, `ReferralActivationTransactionBuild`, `ReferralActivationTransactionSigner`, and related builder param/result interfaces.
- Added `encodeBytesToBase64` to the internal base64 module; works in Node (via `Buffer`), Bun, and browser (via `btoa`).

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- The `buildActivateReferralTxRequest` convenience method on `V1InviteClient` makes parallel HTTP calls for the permission account and exchange snapshot; pass pre-fetched `permission` and/or `exchangeAccounts` in the params object to skip those fetches.
- The `signTransaction` callback in `BuildActivateReferralTxRequestParams` accepts a Kit `Transaction`, a base64 string, raw `Uint8Array`/`ArrayBuffer`, or any object with a `serialize()` method — covering both `@solana/kit` and legacy `@solana/web3.js` `VersionedTransaction` adapters.
- `rentPayer` on `BuildReferralActivationTransactionParams` is deprecated: the tx-based activation flow no longer creates trader accounts on-chain. Register the trader before calling this flow.

## v0.4.50 - 2026-06-23

Source Phoenix commit: `d1ccda811fc68e0cbf1fbf5d3e6d0235d508c3db`

### Summary

- New `buildSetPermissionDelegatedIx` instruction builder and `SetPermissionDelegated` codec (encoder/decoder) allow a delegated trader-management key to grant trader-onboarding permission to a third-party user key, without requiring the risk authority to sign directly.
- Two permission bitmask constants exported: `TRADER_ONBOARDING_PERMISSION` (`1n << 4n`) and `TRADER_MANAGEMENT_PERMISSION` (`1n << 7n`).
- New types exported: `SetPermissionDelegatedParams`, `SetPermissionDelegatedIx`, `SetPermissionDelegatedAccounts`.
- **Bug fix**: `buildCreatePermissionIx` now marks the `payer` account as writable (was previously readonly-signer); callers constructing transactions directly may see a changed account meta for this field.
- New example `08-delegated-trader-management-onboarding.ts` demonstrates the full external-team onboarding flow end-to-end.

### Breaking Changes

- `buildCreatePermissionIx`: the `payer` account is now `writable + signer` instead of `readonly + signer`. If you are serializing or comparing raw account metas from this instruction, the account flags will differ from 0.4.49.

### Consumer Notes

- To use delegated trader-management onboarding, call `buildSetPermissionDelegatedIx` with a `SetPermissionDelegatedParams` — the authority can be the risk authority itself or any key that holds `TRADER_MANAGEMENT_PERMISSION`. Pass `authorityPermissionAccount` as the authority's own address when it is the risk authority, or as the PDA from `getPermissionAddress` otherwise.
- `TRADER_ONBOARDING_PERMISSION` and `TRADER_MANAGEMENT_PERMISSION` are exported as `bigint` constants; use them for bitwise checks against `permission.permission` fields.
- The new codec exports (`getSetPermissionDelegatedInstructionEncoder/Decoder/Codec`) follow the same pattern as the existing `SetPermission` variants and are available for manual instruction construction or decoding.

## v0.4.49 - 2026-06-23

Source Phoenix commit: `e8c6dd02a2ac562e3d38cf3c4b3027b39ae8985f`

### Summary

- Updated example source-reference comments to reflect the current Rust example path (`rise/rust/examples/` instead of the former `rise/rust/sdk/examples/`) across `01-http-client.ts`, `02-ws-fills.ts`, `03-build-limit-order-ix.ts`, and `examples/README.md`.
- No changes to public TypeScript exports, HTTP client, WebSocket adapters, or generated types in this release.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- None identified in the synced diff.

## v0.4.48 - 2026-06-22

Source Phoenix commit: `a419e23d7d1b2a3e37696d76e85fac7f0a023f5e`

### Summary

- Added `UncrossCrank` instruction: triggers an uncross crank on an orderbook to match resting crossed orders. Exported as `buildUncrossCrankIx`, `buildUncrossCrank`, `uncrossCrank`, `buildUncrossCrankIxResolved`, and associated types/codecs (`UncrossCrankParams`, `UncrossCrankIx`, `UncrossCrankAccounts`, `UncrossCrankInstruction`).
- Promoted `CancelUpTo` to the full public SDK surface: `buildCancelUpTo`, `cancelUpToOrders`, `buildCancelUpToIxResolved`, `BuildCancelUpToIxResolvedInput`, `ClientCancelUpToInput` are now exported and available on `client.ixs`.
- `cancelAllOrders` now accepts an optional `traderSubaccountIndex` in its options (defaults to `0`; fully backward compatible).

### Breaking Changes

- **`buildCancelUpToIx` account-role change**: `globalConfigurationAddress` is now passed as **writable** instead of readonly. Any pre-built or cached `CancelUpTo` transaction assembled with `0.4.47` will fail on-chain due to the account-meta mismatch. Rebuild affected transactions after upgrading.

### Consumer Notes

- `buildUncrossCrankIxResolved` defaults `matchLimit` to `100n` when the parameter is omitted; pass an explicit value to override.
- `UncrossCrankParams.matchLimit` is typed as `bigint` (required, non-negative). The high-level `buildUncrossCrank` / `ClientUncrossCrankInput` accept `bigint | number` and coerce automatically.
- All new exports are available from the package root (`@ellipsis-labs/rise`); no sub-path import changes are required.

## v0.4.47 - 2026-06-22

Source Phoenix commit: `472a79816f0e119910a009795ae3c8cd7e39b054`

### Summary

- The default localnet fixture (`test-fixtures/default-localnet.json`) is now bundled in the npm package and exported as a named package path, enabling consumers to import it directly without a local copy.
- Market entries in the localnet fixture now include `defaultTakerFeeMicro` (350) and `defaultMakerFeeMicro` (50) fields for BTC, ETH, and SOL markets.
- A new test assertion verifies that the packaged fixture copy stays in sync with the canonical root fixture.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- **New package export**: `@ellipsis-labs/rise/test-fixtures/default-localnet.json` is now a stable named export. Consumers can import the default localnet fixture directly from the package instead of copying it or referencing it by relative path.
- **Fixture schema addition**: Each market object in the localnet fixture now carries `defaultTakerFeeMicro` and `defaultMakerFeeMicro` numeric fields. Code that deserializes the fixture into a typed struct should treat these as new optional fields; strict deserializers that reject unknown fields will need updating.
- The `test-fixtures/` directory is now included in the published `files` list; the fixture JSON is part of the public package surface and subject to semver considerations going forward.

## v0.4.46 - 2026-06-22

Source Phoenix commit: `fd9d044ad0e76e6bcbef1333b1ebc8648f511b7a`

### Summary

- Added `MarketStatsSnapshot` interface and `MarketStatsSnapshotSchema` as new public exports from `@ellipsis-labs/rise`.
- `ExchangeMarketConfig` now includes an optional `statsSnapshot?: MarketStatsSnapshot` field containing slot, open interest, funding interval timestamp, and cumulative funding rate.
- Numeric fields (`openInterestBaseLots`, `fundingStartIntervalTimestamp`, `cumulativeFundingRate`) are coerced to strings at parse time, so the API may return either strings or numbers and the SDK normalizes them.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- Access per-market stats via `market.statsSnapshot` when calling `getMarkets()`. The field is optional and will be `undefined` if the server does not include it.
- `MarketStatsSnapshot` and `MarketStatsSnapshotSchema` are now available as named exports for consumers who want to validate or type this shape independently.

## v0.4.45 - 2026-06-18

Source Phoenix commit: `5b7f20375f7eee51e309f9c4bc994609f5be2d1e`

### Summary

- **Auth-gated channel subscriptions are now deferred on external-session clients.** Subscriptions to the `events`, `notifications`, `trader`, `traderVolume`, and `transaction` channels will no longer be sent over an anonymous WebSocket connection. If no external session has been imported yet, the subscription message is held and replayed automatically on the authenticated connection once a session arrives.
- **Public subscriptions flow immediately over anonymous connections.** Channels not in the auth-required set (e.g. `allMids`, orderbook, trades) are sent to the server right away, even while the client is waiting for an external session to be imported — no unnecessary reconnect is triggered for these channels.
- **Reduced reconnect churn in `external` session control mode.** When a session has not yet been provided, the client now keeps the existing anonymous socket open instead of immediately scheduling a reconnect every time a subscription is registered, resulting in fewer connection disruptions during the authentication waiting period.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- If your application subscribes to auth-required channels (`events`, `notifications`, `trader`, `traderVolume`, `transaction`) before calling `sessionManager.importSnapshot(...)`, those subscribe messages will be buffered and sent once the authenticated connection is established. No code changes are required, but you should be aware that these subscriptions are not active until authentication completes.
- Public channel subscriptions registered before an external session is available will now be active on the anonymous socket immediately, so data for those channels will begin arriving sooner than before.

## v0.4.44 - 2026-06-17

Source Phoenix commit: `2d72d1003db4c5e852d3eef26572cd24da068745`

### Summary

- Added opt-in fee-override support to Flight proxy instructions. When `feeBpsOverride` is set on `PhoenixFlightClientConfig` or `ProxyInstructionParams`, `buildProxyInstructionIx` and `wrapInstructionWithFlight` emit `proxy_instruction_with_fee_override` instead of the standard `proxy_instruction`, allowing an integration route to override the builder's registered fee.
- New `FLIGHT_DISCRIMINANTS.PROXY_INSTRUCTION_WITH_FEE_OVERRIDE` discriminant and associated codec helpers (`encodeProxyInstructionWithFeeOverrideData`, `getProxyInstructionWithFeeOverrideParamsEncoder/Decoder/Codec`, `getProxyInstructionWithFeeOverridePrefixEncoder`, `ProxyInstructionWithFeeOverrideParamsData`) are now exported from the package.
- `instructions.json` gains the deterministic `ProxyInstructionWithFeeOverride` entry for snapshot testing and tooling.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `feeBpsOverride` (`bigint | null`) is an optional, additive field on both `PhoenixFlightClientConfig` and `ProxyInstructionParams`; omitting it (or passing `null`) preserves existing behavior with no code changes required.
- When `feeBpsOverride` is provided, `buildProxyInstructionIx` validates that the value is in the range `0n–10_000n` (inclusive) and throws `"Fee bps override must be in the range 0..=10000"` if not.
- The fee-override path emits an on-chain instruction with a different discriminant (`PROXY_INSTRUCTION_WITH_FEE_OVERRIDE`), so infrastructure that inspects raw instruction bytes or discriminants (parsers, indexers, monitoring) should be updated to recognize the new variant.

## v0.4.43 - 2026-06-17

Source Phoenix commit: `e01d6bf79f112b8f9c7c6e7e3ad84fb83050eb43`

### Summary

- **Hawkeye program client**: Added a full read-only simulation client for the Hawkeye program (`RiSeVw3ZjNfsaXPRb4mgaqYaEEt41pNNJoDvVh7pgQj`). Call `client.rpc.hawkeye.viewMargin(...)`, `.viewMarginForAsset(...)`, `.viewLiquidationPrice(...)`, `.viewBbo(...)`, and `.viewFunding(...)` to query on-chain margin, risk state, liquidation price, BBO, and funding data via transaction simulation — no signature required.
- **New root-level exports**: Five instruction builders (`buildHawkeyeViewMarginIx`, `buildHawkeyeViewMarginForAssetIx`, `buildHawkeyeViewLiquidationPriceIx`, `buildHawkeyeViewBboIx`, `buildHawkeyeViewFundingIx`), `decodeHawkeyeReturnData`, `encodeHawkeyeSimulationTransaction`, `HAWKEYE_PROGRAM_ADDRESS`, `HAWKEYE_SIMULATION_COMPUTE_UNIT_LIMIT`, and all associated TypeScript types (`HawkeyeReturnData`, `HawkeyeMarginReturn`, `HawkeyeAssetReturn`, `HawkeyeLiquidationPriceReturn`, `HawkeyeBboReturn`, `HawkeyeFundingReturn`, etc.) are now exported from the package root.
- **`PhoenixIxClient` additions**: Five new `buildHawkeyeView*` methods on the ix client automatically resolve trader accounts and asset IDs from authority/symbol, mirroring the existing client pattern.
- **`zod` pinned to `4.4.3`** (previously `^4.3.6`).

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- `PhoenixRpcAccountFetcherClient.request` was widened from `private` to `public`; this is additive and does not break existing code, but the method is now formally part of the class surface.
- The `zod` dependency is now pinned to the exact version `4.4.3`. If your project declares `zod` as a direct dependency and previously resolved `^4.3.6` to a different patch, verify your lockfile resolves cleanly after upgrading to this version of `@ellipsis-labs/rise`.

## v0.4.42 - 2026-06-16

Source Phoenix commit: `ee8192d915d1d282849dc7e70d84db2e51cbba42`

### Summary

- Added optional `permissionAddress` field to `ClientTransferCollateralInput`, `ResolvedTransferCollateralIxInput`, and `TransferCollateralParams` to support secondary position authority delegation in `TransferCollateral` instructions. When provided, the address is appended as a writable account on the instruction.
- `PlaceMarketOrderDelegated` instructions are no longer wrapped by the Flight router (`wrapInstructionWithFlight` / `isFlightRoutableInstruction`); they are passed through unchanged.
- `FlightPlaceMarketOrderDelegated` has been removed from the exported `instructions.json` fixture.

### Breaking Changes

- **`FlightPlaceMarketOrderDelegated` removed from `instructions.json`**: Consumers that read this key from the package's `instructions.json` export will find it absent. Remove any reference to `instructions["FlightPlaceMarketOrderDelegated"]` in downstream code.
- **Delegated market orders no longer Flight-routed**: `isFlightRoutableInstruction` and `wrapInstructionWithFlight` no longer recognize `PLACE_MARKET_ORDER_DELEGATED` instructions. If your code relied on the Flight router wrapping delegated market orders, those instructions will now be returned unchanged. Update any logic that expected a Flight-wrapped delegated market order to handle the pass-through behavior.

### Consumer Notes

- The new `permissionAddress` field on `ClientTransferCollateralInput` and `ResolvedTransferCollateralIxInput` is optional and backward compatible; no changes required if you are not using position authority delegation for collateral transfers.
- If you pass a `permissionAddress`, it is included as the last account (writable) on the resulting `TransferCollateral` instruction — account index assumptions in any manual account-position logic should account for this trailing account.

## v0.4.41 - 2026-06-16

Source Phoenix commit: `6487be852f3a382717f345a43fd956af3fba1766`

### Summary

- `PhoenixHttpClient` now automatically retries `GET` and `HEAD` requests that receive a `429 Too Many Requests` response. By default, up to 2 retries are attempted with a cumulative wait cap of 15 seconds, honoring the server's `Retry-After` header (both numeric seconds and HTTP-date formats). Pass `rateLimitRetry: false` to opt out.
- A new `rateLimitRetry` config field on `PhoenixHttpClientConfig` accepts a `RateLimitRetryConfig` object (`maxRetries`, `maxTotalWaitMs`, `fallbackDelayMs`) or `false` to disable retries entirely.
- `PhoenixHttpError` gains an `attempts` field (number of total attempts including the initial request) so callers can distinguish a first-shot 429 from one that exhausted retries.
- `RateLimitRetryConfig` is now exported from the package root (`@ellipsis-labs/rise`).
- `Retry-After` parsing is now unified and more accurate: supports both numeric seconds (including fractional) and HTTP-date strings; previously, `transport.ts` parsed only integers and clamped to a minimum of 1 second.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- **Default retry behavior is now active.** Existing code that calls `GET`/`HEAD` endpoints may now wait and retry on 429s (up to ~15 s total) instead of failing immediately. If your application handles 429s manually or has strict latency budgets, pass `rateLimitRetry: false` to restore the prior behavior.
- **`PhoenixHttpError.attempts` is additive** — no code changes required, but error-inspection code that checks for a fixed set of fields may now observe this new property on 429 errors.

## v0.4.40 - 2026-06-16

Source Phoenix commit: `65fc5aad3e13c249bcc606b410059b8adbc61e2d`

### Summary

- **Fixed liquidation price calculation**: The formula for computing a position's liquidation price now correctly incorporates the market's `maintenanceMarginFactorBps` risk parameter. Previously the formula used a simplified approximation; it now derives the denominator and numerator using the actual maintenance margin coefficient, producing more accurate results across leverage tiers.
- **Fixed unsettled funding sign convention in snapshot helpers**: `buildMarginPositionStateFromSnapshot` no longer negates `unsettledFundingQuoteLots` when converting from a snapshot. The field is now passed through as-is, matching the margin-engine sign convention (positive = increases effective collateral).
- **Clarified `MarginPositionState.unsettledFundingQuoteLots` documentation**: The JSDoc on this field no longer instructs callers to flip the sign themselves; the snapshot helper now handles the value correctly without manual adjustment.

### Breaking Changes

- **Snapshot-sourced `unsettledFundingQuoteLots` values will differ**: Any code that previously compensated for the sign flip in `buildMarginPositionStateFromSnapshot` (e.g., by negating the field before passing it downstream) must remove that workaround. The value is now passed through with the margin-engine convention intact.
- **Liquidation price outputs will change**: Computed liquidation prices from `computeLiquidationPriceTicks` will differ from prior versions due to the corrected formula. Consumers who cache, display, or act on liquidation price values should expect updated results after upgrading.

### Consumer Notes

- If you construct `MarginPositionState` manually (not via snapshot helpers) and were previously accounting for the sign flip described in the old JSDoc, no change is needed — the type contract is unchanged; only the snapshot helper behavior is fixed.
- The liquidation price fix requires `maintenanceMarginFactorBps` to be present and positive in `MarketParams.riskFactors`; positions with a zero or missing value will return `undefined` for liquidation price (was previously a potentially incorrect value).

## v0.4.39 - 2026-06-15

Source Phoenix commit: `6b96d79ca6d38a289150f382efe441c4116e395c`

### Summary

- **Version bump**: `@ellipsis-labs/rise` is now `0.4.39`.
- **Source files included in package**: The `src/` directory is now bundled in the published npm package alongside `dist/`. Consumers benefit from source availability for debugging and source maps without needing a separate step.
- **Changelog included in package**: `CHANGELOG.md` is now shipped with the npm package, making release notes available locally after install.
- **README documents changelog location**: A new "Changelog" section in the README links to the public Rise TypeScript changelog on GitHub.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- No API, type, or runtime behavior changes in this release — the changes are packaging-only.
- If your bundler or tooling scans `node_modules` for `.ts` source files, the newly included `src/` directory may be picked up; verify your `exclude` or `ignore` patterns if unexpected files appear in your build.

## v0.4.38 - 2026-06-15

Source Phoenix commit: `978cab228c047f8e511a8075621846c679d331d5`

### Summary

- Bumped `ws` peer dependency minimum from `>=8.20.1` to `>=8.21.0`.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- If you pin `ws` to an exact version below `8.21.0`, you may see peer dependency warnings or conflicts. Update your lockfile or pin to `ws@8.21.0` or later.

## v0.4.37 - 2026-06-15

Source Phoenix commit: `5a524ada417b9cce3f94096900c59b4ec5fc17ec`

### Summary

- Bumped `@ellipsis-labs/rise` from `0.4.36` to `0.4.37`.
- Upgraded Vite from `7.3.2` to `8.0.16` (major version bump) in the package's build tooling and pinned override.
- Vite 8 replaces `rollup` and `esbuild` as core bundler with `rolldown` (Rust-based) and adds `lightningcss` as a required CSS processor.

### Breaking Changes

- **Vite 8 bundler switch**: Vite 8 drops `rollup` and `esbuild` as core bundler dependencies in favor of `rolldown`. If your project extends the `@ellipsis-labs/rise` build config or shares a Vite instance, any use of `build.rollupOptions` or esbuild-specific plugin APIs may require updates.
- **`esbuild` is now an optional peer in Vite 8**: Consumers who relied on esbuild being available transitively through Vite will need to add it explicitly if their own config references esbuild transforms or plugins.

### Consumer Notes

- No public TypeScript API changes in this release — types, exports, and runtime behavior are unchanged.
- If your project uses Vite and this package's `vite` override propagates into your lock file, you will be upgraded to Vite 8. Review the [Vite 8 migration guide](https://vite.dev/guide/migration) for `rollupOptions` and plugin compatibility.
- `lightningcss` is now a first-class dependency of Vite 8 (no longer an optional peer); CSS processing behavior may differ subtly from esbuild's CSS pipeline.

## v0.4.36 - 2026-06-15

Source Phoenix commit: `8809c4d39c7070f6430c20dd5fe670ad86032523`

### Summary

- Version bumped from `0.4.35` to `0.4.36`.
- No functional code, API, or type changes are included in this sync — the diff contains only the version field update in `package.json`.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- None identified in the synced diff.

## v0.4.35 - 2026-06-15

Source Phoenix commit: `0499d27df18bb2694c5489a9395bec0a58d1d141`

### Summary

- Version bumped from `0.4.34` to `0.4.35`.
- Add-market setup payloads now encode an after-hours radius field. The field is a `u64` appended at the end of the instruction data and defaults to `0` (no after-hours radius).

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- The encoded size of add-market instructions has changed to 345 bytes to accommodate the new after-hours radius field. If your code hard-codes or validates the byte length of these instruction payloads, update it accordingly.
- The after-hours radius defaults to `0n` (disabled), so existing integrations that do not set this field should continue to work without modification.

## v0.4.34 - 2026-06-15

Source Phoenix commit: `c25ccb579ff367b65aedf254320d6a54da56613f`

### Summary

- Added `MaxLiquidationSizeUpdated` exchange market parameter update event: new `interface MaxLiquidationSizeUpdated` with `kind: "maxLiquidationSizeUpdated"`, `previousBaseLots: bigint`, and `newBaseLots: bigint`.
- `MaxLiquidationSizeUpdated` is now included in the `ExchangeMarketParameterUpdate` discriminated union and recognized by the WebSocket wire adapter's known-kinds set and Zod schema.
- The exchange cache store now maps `"maxLiquidationSizeUpdated"` events to the `"maxLiquidationSize"` change kind and applies `update.newBaseLots` to `nextMarket.maxLiquidationSizeBaseLots`.
- `"maxLiquidationSize"` added to the `ExchangeCacheMarketChangeKind` union type.

### Breaking Changes

- None identified in the synced diff.

### Consumer Notes

- Consumers subscribing to exchange market parameter updates will now receive `maxLiquidationSizeUpdated` events. If you have exhaustive switch/discriminated-union handling over `ExchangeMarketParameterUpdate`, TypeScript will require you to handle the new `MaxLiquidationSizeUpdated` variant.
- If you use `ExchangeCacheMarketChangeKind` exhaustively (e.g., in a switch or mapped type), add a case for `"maxLiquidationSize"` to avoid compilation errors.

## v0.4.33 - 2026-06-15

Source Phoenix commit: `d1c6f3dea8582f451d616bc42b1a083f9fa04000`

### Summary

- `V1TradersClient.getTraderState()` has been removed; the replacement `getTraderStateSnapshot()` is the only trader state method going forward.
- Two new collateral history methods added to `V1CollateralClient`: `getTraderPdaCollateralHistory()` for single-page lookups by trader PDA pubkey, and `getAllTraderPdaCollateralHistory()` for auto-paginated full history.
- All internal HTTP routes have been updated to versioned `/v1/` prefixes; existing method call signatures are unchanged for consumers using the SDK client normally.

### Breaking Changes

- **`V1TradersClient.getTraderState(authority, request?)` removed** along with the `TraderStateRequest` interface and `TraderStateResponse`/`TraderStateResponseSchema` exports. Migrate to `getTraderStateSnapshot(authority, { traderPdaIndex })`, which returns a `TraderStateSnapshotResponse` with `traderPdaIndex` and `snapshot.subaccounts`.
- **Exchange endpoints migrated** from `/exchange/*` to `/v1/view/exchange/*`. Consumers building mock HTTP interceptors, test transports, or calling the API directly (bypassing the SDK client) must update these paths: `getExchange`, `getMarket`, `getStatus`, `getKeys`, and `getMarkets`.
- **Market fills endpoint** changed from `/market/{symbol}/fills` to `/v1/trades/{symbol}/fills`; **trader PnL endpoint** changed from `/trader/{authority}/pnl` to `/v1/users/{authority}/pnl`. Same impact scope as above.

### Consumer Notes

- `getTraderCollateralHistory(authority, { pdaIndex? })` continues to work for authority-based lookups via `/v1/trader/{authority}/collateral-history` (path now carries the `v1` prefix internally, but the method signature is unchanged).
- New `getTraderPdaCollateralHistory(traderPubkey, request?)` targets `/v1/traders/{traderPubkey}/collateral-history` — use this when you have the trader PDA pubkey directly rather than the authority.
- New `getAllTraderPdaCollateralHistory(traderPubkey, pageSize?, request?)` auto-paginates until `hasMore` is false and returns the flat event array; the default page size is 1000.

## v0.4.32 - 2026-06-15

Source Phoenix commit: `3506fd24b235813df18d1897c9ff076417c19ee8`

### Summary

- Added a new `PlaceMarketOrderDelegated` instruction that allows placing market orders signed by a delegated wallet distinct from the trader account authority. Supports both an explicit `traderWallet`/`permissionAccount` pair and a default fallback to the position authority.
- Exported the full `PlaceMarketOrderDelegated` surface: low-level builder (`buildPlaceMarketOrderDelegatedIx`), codec helpers (`getPlaceMarketOrderDelegatedEncoder/Decoder/Codec`), higher-level builders (`buildPlaceMarketOrderDelegated`, `buildPlaceMarketOrderDelegatedIxResolved`), a fire-and-send helper (`placeMarketOrderDelegated`), and the associated TypeScript types.
- `PlaceMarketOrderDelegated` instructions are now recognized as Flight-routable, matching the same Flight-wrapping behavior as `PlaceMarketOrder`.
- `instructions.json` now includes canonical discriminant hex entries for both `PlaceMarketOrderDelegated` and `FlightPlaceMarketOrderDelegated`.

### Breaking Changes

- **`PhoenixIxClient` interface extended**: `buildPlaceMarketOrderDelegated` and `placeMarketOrderDelegated` methods are added to the `PhoenixIxClient` interface. Any downstream code that manually implements this interface will fail to compile until the two new methods are added.

### Consumer Notes

- When `traderWallet` and `permissionAccount` are omitted from `ClientPlaceMarketOrderDelegatedInput`, the SDK defaults both to `positionAuthority` (falling back to `authority`), so the method works as a drop-in for the primary position authority signing flow.
- The `traderWallet` account is encoded as `READONLY_SIGNER` (account index 3) and `permissionAccount` as writable (account index 4) — relevant if you inspect raw account lists.
- `buildPlaceMarketOrderDelegated` and `placeMarketOrderDelegated` are available on both the root package export and the `PhoenixIxClient` / `PhoenixIxOperations` client objects.

## v0.4.31 - 2026-06-11

Source Phoenix commit: `443ff8dfd64a9e7d35960b8b1946b3248d6681e5`

### Summary

- Added `V1TradesClient.getUserLiquidationHistory(userPubkey, request?)` — a new paginated endpoint (`GET /v1/users/{pubkey}/liquidation-history`) returning typed liquidation events for three kinds: `market_order`, `backstop`, and `adl`.
- All `RiskFactors` fields (`maintenance`, `backstop`, `highRisk`, `upnl`, `upnlForWithdrawals`, `cancelOrder`) now carry **basis-point values** (e.g. `5000` = 50%) throughout the projected-market and margin layers; previously they held percentage values.
- `ExchangeRiskFactors` and `ExchangeLeverageTier` gain optional `*Bps` companion fields populated by the exchange cache and WebSocket store; the legacy percentage fields remain present.
- WebSocket risk-factor update events (`cancelRiskFactorUpdated`, `upnlRiskFactorUpdated`, `upnlRiskFactorForWithdrawalsUpdated`) gain optional `previousBps`/`newBps` fields, normalized from server snake_case.

### Consumer Notes

- New liquidation history types (`UserLiquidationHistoryPoint` and subtypes `UserMarketLiquidationHistoryPoint`, `UserBackstopLiquidationHistoryPoint`, `UserAdlLiquidationHistoryPoint`) are exported from the public surface; narrow on the `kind` discriminant to access type-specific fields.
- `ExchangeRiskFactors` percentage fields remain for backward compatibility on the exchange config/snapshot layer; prefer the new `*Bps` variants when present.
- Limit of 100 items per `getUserLiquidationHistory` request; use `nextCursor`/`prevCursor` for pagination.

## v0.4.30 - 2026-06-11

Source Phoenix commit: `7b0e722849fbc44d2d34d481d208db0ea951b78e`

### Summary

- **Risk factor values in `RiskFactors` are now in basis points.** `PhoenixProjectedMarket.riskFactors` fields (`maintenance`, `backstop`, `highRisk`, `upnl`, `upnlForWithdrawals`, `cancelOrder`) now carry bps values (e.g. `5000` = 50%) instead of the previous percentage scale (e.g. `5` = 5%). The cache store, projected-market selector, and margin params builder all consistently prefer the new bps representation.
- **Optional `*Bps` sibling fields added to `ExchangeRiskFactors` and `ExchangeLeverageTier`.** `maintenanceBps`, `backstopBps`, `highRiskBps`, `upnlBps`, `upnlForWithdrawalsBps`, `cancelOrderBps`, and `limitOrderRiskFactorBps` are now available on the HTTP API types; where present they take precedence over the legacy percentage fields.
- **WebSocket risk-factor update events carry optional bps deltas.** `cancelRiskFactorUpdated`, `upnlRiskFactorUpdated`, and `upnlRiskFactorForWithdrawalsUpdated` now include `previousBps`/`newBps` (normalized from server snake_case `previous_bps`/`new_bps`).
- **`buildMarketParamsFromSummary` now validates risk factor inputs strictly.** Passing a non-finite, negative, non-integer, or >10 000 bps value throws an explicit error instead of silently stringifying it.

### Breaking Changes

- **`buildMarketParamsFromSummary` can now throw.** If a `MarketSummary` contains risk factor values that are non-finite, negative, non-integer bps, or exceed 10 000 bps, the function throws instead of returning a params object. Callers that previously relied on unconditional success should wrap the call or validate inputs first.

### Consumer Notes

- The legacy percentage-scale fields on `ExchangeRiskFactors` (`maintenance`, `backstop`, etc.) remain present for backwards compatibility with older API responses; prefer the new `*Bps` fields when available.
- WS consumers parsing `cancelRiskFactorUpdated`, `upnlRiskFactorUpdated`, or `upnlRiskFactorForWithdrawalsUpdated` events can now read `newBps`/`previousBps` directly; the wire adapter normalizes snake_case `new_bps`/`previous_bps` from the server automatically.

## v0.4.28 - 2026-06-10

Source Phoenix commit: `f0c4a154e63048a8517e72e8a6a8b806e3768cd0`

### Summary

- **New `OnboardTraderDelegated` instruction**: Adds `buildOnboardTraderDelegatedIx`, `buildOnboardTraderDelegated`, and `buildOnboardTraderDelegatedIxResolved` to the public surface. A delegated onboarder keypair can now onboard a trader (optionally registering the account first) without the risk authority signing directly.
- **New client method**: `client.ixs.buildOnboardTraderDelegated({ authority, traderAuthority, permissionAccount, traderPdaIndex?, traderSubaccountIndex? })` is available on all `PhoenixIxClient` instances.
- **New example**: `examples/07-onboard-trader-delegated.ts` demonstrates the full delegated onboarding flow, including permission validation and conditional trader registration.

### Consumer Notes

- The `TraderCapabilityToggleTarget` enum and internal `buildSetTraderCapabilitiesDelegated*` names are intentionally absent from the public surface; use `buildOnboardTraderDelegated` instead.
- Delegated onboarding always enables all six trader capabilities (limit orders, market orders, risk-increasing and risk-reducing trades, deposit, and withdrawal) in a single instruction — there is no partial-capability variant in this release.
- The `permissionAccount` address must be derived from the current risk authority and the onboarder's key; see the new example for the full derivation pattern using `client.pda.getPermissionAddress`.

## v0.4.27 - 2026-06-09

Source Phoenix commit: `32611fa7f803cf601cab67b6ca5dce5d4a70fc75`

### Summary

- Flame proxy-deposit flow added for sponsored USDC deposits that bypass user-owned rent accounts
- Market calendar APIs and per-market public metadata (`name`, `logoUri`, `calendar`, `coinGeckoId`, etc.) are now available in the HTTP client and exchange cache
- Auth robustness improved: expired sessions are proactively refreshed before WS connect, transient refresh failures retry with backoff, and `auth: "required"` HTTP requests fail immediately without a valid session

### Breaking Changes

- **`apiKey` removed** from `PhoenixHttpClientConfig` and `createPhoenixClient`. Any call site passing `apiKey` will now fail to compile; remove the field.
- **`activateInviteWithReferral` renamed to `activateReferral`** on the invite client. The backing route changed from `POST /v1/invite/activate-with-referral` to `POST /v1/referral/activate`, which now requires an active auth session for the same authority wallet.
- **`fromSnapshot` now reads `expiresAt` from the JWT `exp` claim** (not the snapshot's `expiresAt` field) and throws if `exp` is absent. Access tokens lacking `exp` are no longer accepted.
- **`PhoenixExchangeStoreState` interface gained three required fields** (`marketMetadataBySymbol`, `marketMetadataByAssetId`, `marketMetadataByPubkey`). Downstream code that constructs or types this shape directly (e.g. in tests) must add these fields.
- **`ExchangeCacheMarketChangeKind` union gained `"metadata"`**. Exhaustive `switch` or conditional chains over this type without a default branch will fail to compile unless updated.

### Consumer Notes

- **New Flame deposit helpers**: `buildFlameDepositFundingFlow`, `deriveFlameDepositAddresses`, `deriveFlameProxyAuthorityAddress`, `deriveFlameDepositAddress`, `FLAME_PROGRAM_ADDRESS`, `FlameProgramAddress`. Use `buildFlameDepositFundingFlow` for sponsored deposits; `buildDepositFlow` remains the direct Ember + Phoenix path.
- **New market calendar endpoints** on the markets client: `getMarketCalendar(symbol)`, `getMarketCalendarById(id)`, `getCommodityMarketCalendar()`, `getNextMarketCalendarTransition(symbol)`. Matching types (`MarketCalendarResponse`, `MarketCalendarRecord`, `MarketCalendarView`, `NextMarketCalendarTransition`, etc.) are now exported from the public surface.
- **Per-market public metadata** is now accessible via `selectExchangeMarketMetadata(symbol)` / `selectPhoenixExchangeMarketMetadata(symbol)`, `cache.marketMetadata(symbol)`, and the `metadata` field on `PhoenixExchangeMarketState`. The `ExchangeMarketConfig` response also carries an optional `metadata` field.
- **`PlaceMarketOrderFlowParams` gains optional `minBaseLotsToFill` and `minQuoteLotsToFill`** for fill-size guarantees on market orders. Omitting them preserves existing behavior (no minimum enforced).
- **`buildSplTokenTransfer`** is now exported for building raw SPL token transfer instructions.
- **Unknown WebSocket delta ops** are now normalized to `{ kind: "unknown", originalKind, payload }` instead of throwing, so clients survive new server-side delta kinds without crashing.
